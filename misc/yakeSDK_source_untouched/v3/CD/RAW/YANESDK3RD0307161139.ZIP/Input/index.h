
//	includes..

#include "yaneMouse.h"			//	for mouse input
#include "yaneKeyBase.h"		//	for generic Key Input base class
#include "yaneVirtualKey.h"		//	for Virtual Key Input
#include "yaneMIDIInput.h"		//	for MIDI input
#include "yaneDirectInput.h"	//	for DirectInput
#include "yaneKeyInput.h"		//	for KeyBoard input(using DirectInput)
#include "yaneJoyStick.h"		//	for Joy Stick input
#include "yaneKey.h"			//	concreate Virtual Key
