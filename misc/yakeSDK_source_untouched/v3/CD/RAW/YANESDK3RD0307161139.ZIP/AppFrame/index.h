
//	Application Frame

#include "yaneAppBase.h"		//	application base
#include "yaneAppFrame.h"		//	application frame
#include "yaneAppInitializer.h"	//	application initializer
#include "yaneAppManager.h"		//	application manager
#include "yaneAppDraw.h"		//	application draw base class
#include "yaneSingleApp.h"		//	for single application
#include "yaneFindWindow.h"		//	for finding my window handle
#include "yaneObjectCreater.h"	//	for Object Creating Manager
