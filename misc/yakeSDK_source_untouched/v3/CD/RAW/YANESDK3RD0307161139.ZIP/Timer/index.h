
//	Timing

#include "yaneTimer.h"				//	for Game Timer
#include "yaneFPSTimer.h"			//	for FPS adjusting Timer
#include "yaneIntervalTimer.h"		//	for software IntervalTimer
