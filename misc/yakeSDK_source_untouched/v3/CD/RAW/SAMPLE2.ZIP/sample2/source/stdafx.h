#include "../../../yaneSDK/stdafx.h"
#include "../../../yaneSDK/yaneSDK.h"
