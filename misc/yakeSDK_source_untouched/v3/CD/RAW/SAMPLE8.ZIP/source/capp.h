#pragma once
#include "../../yaneSDK/yaneSDK.h"

class CApp : public CAppFrame {
public:

	virtual void MainThread();
};
