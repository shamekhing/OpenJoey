#include "../../../yaneSDK3rd/AppFrame/stdafx.h"
#include "../../../yaneSDK3rd/yaneSDK.h"
