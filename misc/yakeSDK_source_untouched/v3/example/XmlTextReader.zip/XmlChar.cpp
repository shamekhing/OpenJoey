#include "StdAfx.h"
#include "xmlchar.h"

namespace XmlChar{

XmlChar::XmlChar(void)
{
}

XmlChar::~XmlChar(void)
{
}

bool XmlChar::IsWhitespace(int ch)
{
	return  ch == 0x20 ||
			ch == 0x9  ||
			ch == 0xD  ||
			ch == 0xA;
}

bool XmlChar::IsFirstNameChar(int ch)
{
	bool result = false;

	if (ch >= 0 && ch <= 0xFFFF)
	{
		result = (nameBitmap[(firstNamePages[ch >> 8] << 3) + ((ch & 0xFF) >> 5)] & (1 << (ch & 0x1F))) != 0;
	}

	return result;
}

bool XmlChar::IsNameChar(int ch)
{
	bool result = false;

	if (ch >= 0 && ch <= 0xFFFF)
    {
        result = (nameBitmap[(namePages[ch >> 8] << 3) + ((ch & 0xFF) >> 5)] & (1 << (ch & 0x1F))) != 0;
    }

	return result;
}

};

bool XmlChar::XmlChar::IsPubidChar(int ch)
{
	throw CSyntaxException("�������ł�");
	return false;
}
