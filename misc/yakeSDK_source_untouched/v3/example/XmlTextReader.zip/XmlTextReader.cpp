#include "StdAfx.h"
#include "xmlreader.h"
#include "xmltextreader.h"
#include "XmlChar.h"

//XmlTextReader::XmlTextReader(void){}

XmlTextReader::XmlTextReader(string sFileFullPath)
{
	XmlText.Read(sFileFullPath);
	lp = (LPCSTR)XmlText.GetMemory();

	//�t�B�[���h������
	line = 1;
	column = 1;
	has_peek = false;
	whitespaceHandling = WhitespaceHandling::All;

    //internal void SetReaderContext (string url, XmlParserContext context)
    //{
    //        parserContext = context;
    //        parserContext.BaseURI = url;
            Init ();
    //}

    //internal void SetReaderFragment(TextReader fragment, XmlNodeType fragType)
    //{
    //        this.reader = fragment;
			can_seek = lp != NULL && reader_Peek () != '\0';//-1;
    //}

}

XmlTextReader::~XmlTextReader(void)
{
}

int XmlTextReader::reader_Peek(void)
{
	return *lp;
}

int XmlTextReader::reader_Read(void)
{
	return *lp++;
}

bool XmlTextReader::Read(void)
{
	bool more = false;
	readState = ReadState::Interactive;	//�ǂݍ��ݏ�Ԑݒ�
	more = ReadContent ();
	return more;
}

//	�R���e���c��ǂݍ���
bool XmlTextReader::ReadContent(void)
{

    //currentTag.Length = 0;//����ǂ��Ȃ񂩂���H
    currentTag.clear();

	//���O��Ԑ����΂�
	//if (popScope) {
    //        parserContext.NamespaceManager.PopScope ();
    //        popScope = false;
    //}

	//�Q�ƃG���e�B�e�B������΂�
    //if (returnEntityReference) {
    //        SetEntityReferenceProperties ();
    //} else {
		switch(PeekChar())
		{
		case '<':
			ReadChar ();
			ReadTag ();
			break;
		case '\r':
			/* WhiteSpace������΂� */
			ReadChar ();
			return ReadContent ();
		case '\n':
			/* WhiteSpace������΂� */
			ReadChar ();
			return ReadContent ();
		case ' ':
			/* WhiteSpace������΂� */
			SkipWhitespace ();
			return ReadContent ();
		case '\0'://-1:
			readState = ReadState::EndOfFile;
			SetProperties (
				XmlNodeType::None,//	nodeType
				"",				//	name
				false,			//	isEmptyElement
				"",				//	value
				true			//	crearAttributes
				);
			break;
		default:
			ReadText (true);
			break;
		}
	//}
	return readState != ReadState::EndOfFile;
}

int XmlTextReader::ReadChar(void)
{
	int ch;
	if (has_peek) {
		ch = peek_char;
		has_peek = false;
	} else {
		ch = reader_Read ();
	}
	
	if (ch == '\n') {	//���s�����̏ꍇ
		line++;	//�s�X�V
		column = 1;	//������������
	} else {
		column++;	//�������C���N�������g
	}
	/* xmlBuffer�n��΂�*/
	currentTag = currentTag + (char)ch;
	return ch;
}

int XmlTextReader::PeekChar(void)
{
	if (can_seek)
		return reader_Peek ();
	if (has_peek)
		return peek_char;
	peek_char = reader_Read ();
	has_peek = true;
	return peek_char;
}

void XmlTextReader::ReadTag(void)
{
	switch (PeekChar ())
	{
	case '/':
		ReadChar ();
		ReadEndTag ();
		break;
	case '?':
		ReadChar ();
		ReadProcessingInstruction ();
		break;
	case '!':
		ReadChar ();
		ReadDeclaration ();
		break;
	default:
		ReadStartTag ();
		break;
	}
}


void XmlTextReader::ReadStartTag(void)
{
	//parserContext.NamespaceManager.PushScope ();//cs

	string name = ReadName ();
	SkipWhitespace ();

	bool isEmptyElement = false;

	ClearAttributes ();

	if (XmlChar::XmlChar::IsFirstNameChar (PeekChar ()))
		ReadAttributes ();

	if(PeekChar () == '/') {
		ReadChar ();
		isEmptyElement = true;
		depthDown = true;
		popScope = true;
	}

	Expect ('>');

	SetProperties (
		XmlNodeType::Element,//	nodeType
		name,				//	name
		isEmptyElement,			//	isEmptyElement
		"",				//	value
		false			//	crearAttributes
		);

	if (!depthDown)
		++depth;
	else
		depthDown = false;
}


// �v�f���̎擾
string XmlTextReader::ReadName(void)
{
	if (!XmlChar::XmlChar::IsFirstNameChar (PeekChar ()))
		throw CXmlException("�d�l�ɏ������Ă��Ȃ������Ŏn�܂��Ă��܂�");

	nameLength = 0;
	nameBuffer.clear();//��̍s�̑���

	AppendNameChar (ReadChar ());

	while (XmlChar::XmlChar::IsNameChar (PeekChar ())) {
		AppendNameChar (ReadChar ());
    }
	return CreateNameString ();
}

//�v�f���ɂP�����ǉ�
void XmlTextReader::AppendNameChar(int ch)
{
	//CheckNameCapacity ();
	//nameBuffer [nameLength++] = (char)ch;
	nameBuffer = nameBuffer + (char)ch;
}


string XmlTextReader::CreateNameString(void)
{
    //return new String (nameBuffer, 0, nameLength);
	return nameBuffer;
}

// �z���C�g�X�y�[�X�X�L�b�v
void XmlTextReader::SkipWhitespace(void)
{
	//FIXME: Should not skip if whitespaceHandling == WhiteSpaceHandling.None
	while (XmlChar::XmlChar::IsWhitespace (PeekChar ()))
		ReadChar ();
}

void XmlTextReader::ClearAttributes(void)
{
	if (attributes.size() > 0) {//count�ł͂Ȃ��H
		attributes.clear ();
		orderedAttributes.clear ();
	}
	orderedAttributesEnumerator = NULL;
	//orderedAttributesEnumerator->clear();
}

//�����l���X�g�̍쐬
void XmlTextReader::ReadAttributes(void)
{
	do {
		string name = ReadName (); //�������̎擾
		SkipWhitespace ();
		Expect ('=');
		SkipWhitespace ();
		string value = ReadAttribute ();//�l�̎擾
		SkipWhitespace ();

		/* "xmlns""xmlns:"�̏�����΂� */

		AddAttribute (name, value);
	} while (PeekChar () != '/' &&
			 PeekChar () != '>' &&
			 PeekChar () != '\0');//-1);
}

// �����l����擾����
string XmlTextReader::ReadAttribute(void)
{
	int quoteChar = ReadChar ();

	if (quoteChar != '\'' &&
		quoteChar != '\"')
		throw CXmlException("���p��������܂���");

	valueLength = 0;
	valueBuffer.clear();//��̑���

	while (PeekChar () != quoteChar) {
		int ch = ReadChar ();

		switch (ch)
		{
		case '<':
			throw CXmlException("�����l���Ƀ^�O���ʂ�����܂�");
// expansion of entity now should be done at ResolveAttributeValue() method
//      case '&':
//          ReadReference (true);
//          break;
		case '\0'://-1:
			throw CXmlException("EOF�����o���܂���");
		default:
			AppendValueChar (ch);
			break;
		}
	}

	ReadChar (); //quoteChar

	return CreateValueString ();
}

void XmlTextReader::AppendValueChar(int ch)
{
	/*�z��T�C�Y�Ɍ��E������ꍇ�g�����鏈��
	CheckValueCapacity ();
	valueBuffer [valueLength++] = (char)ch;
	*/
	valueBuffer = valueBuffer + (char)ch;
}

// �����l���̃C���X�^���X����
string XmlTextReader::CreateValueString(void)
{
	return valueBuffer;
}

void XmlTextReader::AddAttribute(string name, string value)
{
	attributes.insert(pair<string,string>(name,value));
	orderedAttributes.push_back(name);
}

// �����T�[�`
void XmlTextReader::Expect(int expected)
{
	int ch = ReadChar ();

	if (ch != expected) {
		throw CXmlException("Expect���s");
	}
}

void XmlTextReader::Expect(string expected)
{
	int len = (int)expected.length();
	for(int i=0; i< len; i++)
		Expect (expected[i]);
}

void XmlTextReader::ReadEndTag(void)
{
	string name = ReadName ();
	SkipWhitespace ();
	Expect ('>');

	--depth;

	SetProperties (
		XmlNodeType::EndElement,
		name,
		false,	//isEnptyElement
		"",
		true	//crearAttributes
		);

	popScope = true;
}

void XmlTextReader::SetProperties(XmlNodeType::XmlNodeType nodeType_,
									string name_,
									bool isEmptyElement_,
									string value_,
									bool clearAttributes_)
{
	nodeType = nodeType_;
	name = name_;
	isEmptyElement = isEmptyElement_;
	value = value_;

	elementDepth = depth;

	if (clearAttributes_)
		ClearAttributes ();
	
	//���O��ԏ�����΂�
	//int indexOfColon = name_.IndexOf (':');
	//if (indexOfColon == -1) {
	//	prefix = String.Empty;
	//	localName = name;
	//} else {
	//	prefix = name.Substring (0, indexOfColon);
	//	localName = name.Substring (indexOfColon + 1);
	//}
    //namespaceURI = LookupNamespace (prefix);
}

void XmlTextReader::ReadText(bool cleanValue)
{
	if(cleanValue)
		valueLength = 0;

	int ch = PeekChar ();

	while (ch != '<' && ch != '\0') {//-1) {
		if (ch == '&') {
			ReadChar ();
			//�Q�Ə�����΂�
			//if (ReadReference (false))
			//	break;
		}else
			AppendValueChar (ReadChar());

		ch = PeekChar ();
	}

	//�Q�ƃG���e�B�e�B������΂�
	//if (returnEntityReference && valueLength == 0) {
	//	SetEntityReferenceProperties ();
	//} else {
		SetProperties (
			XmlNodeType::Text,
			"",
			false,
			CreateValueString (),
			true
			);
	//}

}

void XmlTextReader::Init(void)
{
	readState = ReadState::Initial;

	depth = 0;
	depthDown = false;

	popScope = false;

	nodeType = XmlNodeType::None;
	name = "";
	//prefix = "";
	//localName = "";
	isEmptyElement = false;
	value = "";
	
	orderedAttributesEnumerator = NULL;

	//returnEntityReference = false;
	//entityReferenceName = "";

	//nameBuffer = new char [initialNameCapacity];
	nameLength = 0;

	//xmlBuffer//���g�p
	//currentTag//�������ς�
}

void XmlTextReader::ReadProcessingInstruction(void)
{
	string target = ReadName ();
	SkipWhitespace ();

	valueLength = 0;
	valueBuffer.clear();//��̑���

	while (PeekChar () != '\0') { //-1) {
		int ch = ReadChar ();

		if (ch == '?' && PeekChar () == '>') {
			ReadChar ();
			break;
		}

		AppendValueChar ((char)ch);
	}

	/* '?'�ŗL�̏�����΂� */

	SetProperties (
		target == "xml" ?
		XmlNodeType::XmlDeclaration :
		XmlNodeType::ProcessingInstruction,
		target, //name
		false, // isEmptyElement
		CreateValueString (), // value
		true //crearAttributes
		);


}

void XmlTextReader::ReadDeclaration(void)
{
	int ch = PeekChar ();

	switch (ch)
	{
	case '-':
		Expect ("--");
		ReadComment ();
		break;
	case '[':
		throw CSyntaxException("CDATA�錾�͎�������Ă��܂���");
	case 'D':
		throw CSyntaxException("DOCTYPE�錾�͎�������Ă��܂���");
	}
}


void XmlTextReader::ReadComment(void)
{
	valueLength = 0;
	valueBuffer.clear();//��̑���

	while (PeekChar () != '\0') { //-1) {
		int ch = ReadChar ();

		if (ch == '-' && PeekChar () == '-') {
			ReadChar ();

			if (PeekChar () != '>')
				throw CXmlException("�R�����g������'--'�͊܂߂��܂���");

			ReadChar ();
			break;
		}

		AppendValueChar ((char)ch);
	}

	SetProperties (
		XmlNodeType::Comment, // nodeType
		"", //name
		false, // isEmptyElement
		CreateValueString (), //value
		true //crearAttributes
		);
}

bool XmlTextReader::MoveToNextAttribute(void)
{
	if (attributes.size() == 0/* == NULL */)
		return false;

	if (orderedAttributesEnumerator == static_cast<vector<string>::iterator >(NULL)) {//NULL��int�ł��邱�Ƃւ�waning�΍�i�Ȃ�ł���Ȏ����ɂ�Ȃ��̂���[�j
		SaveProperties ();
		orderedAttributesEnumerator = orderedAttributes.begin();
	}

	if (orderedAttributesEnumerator != orderedAttributes.end()) {
		string name = *orderedAttributesEnumerator;

		string value = (attributes.find(name))->second;
		SetProperties (
			XmlNodeType::Attribute, // nodeType
			name, // name
			false, // isEmptyElement
			value, // value
			false // clearAttributes
			);
		orderedAttributesEnumerator++;
		return true;
	}

	return false;
}

void XmlTextReader::SaveProperties(void)
{
    saveNodeType = nodeType;
    saveName = name;
    //savePrefix = prefix;
    //saveLocalName = localName;
    //saveNamespaceURI = namespaceURI;
    saveIsEmptyElement = isEmptyElement;
    //// An element's value is always String.Empty.
}

XmlNodeType::XmlNodeType XmlTextReader::get_NodeType(void)
{
	return nodeType;
}

int XmlTextReader::get_Depth(void)
{
	return elementDepth;
}

bool XmlTextReader::get_IsEmptyElement(void)
{
	return isEmptyElement;
}

string XmlTextReader::get_Name(void)
{
	return name;
}

string XmlTextReader::get_Value(void)
{
	return value;
}

void XmlTextReader::Close(void)
{
	XmlText.Close();
	readState = ReadState::Closed;
}
