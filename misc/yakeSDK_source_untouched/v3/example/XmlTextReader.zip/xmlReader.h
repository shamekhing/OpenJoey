#pragma once

#include "stdafx.h"

namespace XmlNodeType{
	enum XmlNodeType {
        None = 0,
        Element = 1,
        Attribute = 2,
        Text = 3,
        CDATA = 4,
        EntityReference = 5,
        Entity = 6,
        ProcessingInstruction = 7,
        Comment = 8,
        Document = 9,
        DocumentType = 10,
        DocumentFragment = 11,
        Notation = 12,
        Whitespace = 13,
        SignificantWhitespace = 14,
        EndElement = 15,
        EndEntity = 16,
        XmlDeclaration = 17,
    }; // XmlNodeType
}

namespace ReadState{
    enum ReadState {
        Initial = 0,
        Interactive = 1,
        Error = 2,
        EndOfFile = 3,
        Closed = 4,
    }; // ReadState
}

namespace WhitespaceHandling{
    enum WhitespaceHandling {
        All = 0,
        Significant = 1,
        None = 2,
    }; // WhitespaceHandling
}

class CXmlException : public CException {
///		Xml���@�G���[�ɂ��A�N�Z�X��O
public:
	CXmlException(const string& strErrorName) : m_str(strErrorName) {}	
	virtual string getError() const {
		return m_str;
	}
	string m_str;
};
