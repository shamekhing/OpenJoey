﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Diagnostics;
using System.Windows.Forms;

using Yanesdk.Script;

namespace LuaTest
{
	static class Program
	{
		[STAThread]
		static void Main()
		{
			Yanesdk.Draw.SDLWindow2DGl window = new Yanesdk.Draw.SDLWindow2DGl();
			window.SetVideoMode(640, 480, 0);

			using (Lua lua = new Lua())
			{
				// スクリプトへのデータの受け渡し
				lua["window"] = window; // C#側で作ったオブジェクトでもOK。(´ー`)
				lua.NewTable("data");
				lua.GetTable("data")["text"] = "日本語も大丈夫！";

				try
				{
					object[] result = lua.DoFile("test.lua");
					// ↓戻り値はこんな感じで受け取れる。intじゃなくdoubleなところに注意。
					Debug.Assert((double)result[0] != 33.0 || (double)result[1] != 55.0); 

					// 何度も呼ぶときは、その度にDoFile()やDoString()だと重いので、
					// LoadFile(), LoadString()を用いると良い。
					LuaInterface.LuaFunction function = lua.LoadString(TEST_SCRIPT);
					while (Yanesdk.Draw.SDLFrame.PollEvent() == Yanesdk.Ytl.YanesdkResult.NoError)
					{
						function.Call();

						// Lua側で作ったオブジェクトもちゃんと持ってこれる
						Yanesdk.Timer.FpsTimer timer = (Yanesdk.Timer.FpsTimer)lua["timer"];
						timer.WaitFrame();
					}

					// ※ C#とLuaの間をまたぐようなcoroutineは使えないので、coroutineを使うなら、
					// このwhile自体もLua側に持って行ってしまう方がいいかもしれない。
				}
				catch (LuaInterface.LuaException e)
				{
					// Lua側でエラーが起きた場合、ここに飛んでくる。
					MessageBox.Show(e.GetType() + ": " + e.Message + "\r\n" + e.StackTrace);
				}
			}
		}

		// お試し用スクリプトのデータ。
		const string TEST_SCRIPT = @"
	window.Screen:Select()
	window.Screen:Clear()

	-- 描画
    window.Screen:Blt(tx, x, y)

    -- てきとーに動かしてみる。
    x = x + vx
    y = y + vy
    if x < 0 then
        x = - x
        vx = -vx
    end
    if y < 0 then
        y = - y
        vy = -vy
    end
    if window.Width - tx.Width <= x then
        x = (window.Width - tx.Width) * 2 - x
        vx = -vx
    end
    if window.Height - tx.Height <= y then
        y = (window.Height - tx.Height) * 2 - y
        vy = -vy
    end

	window.Screen:Update()
";

	}
}