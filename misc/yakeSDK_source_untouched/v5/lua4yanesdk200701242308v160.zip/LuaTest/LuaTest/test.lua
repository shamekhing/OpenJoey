
YT = luanet.Yanesdk.Timer
YD = luanet.Yanesdk.Draw
YY = luanet.Yanesdk.Ytl
SDL = luanet.Sdl.SDL

timer = YT.FpsTimer()
timer.Fps = 30

--window = YD.SDLWindow2DGl()
window:SetCaption("日本語テスト: " .. data["text"])

tx = YD.GlTexture()
surface = YD.Surface()
surface:CreateDIB(32, 32, false)
SDL.SDL_FillRect(surface.SDL_Surface, luanet.System.IntPtr.Zero, 0xff00ff)
tx:SetSurface(surface)

x = 200
y = 100
vx = 16
vy = 10

-- 戻り値も試してみる。
return 33, 55

