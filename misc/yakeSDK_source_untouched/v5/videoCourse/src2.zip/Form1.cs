﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using Yanesdk.Ytl;
using Yanesdk.Network;


namespace WindowsApplication4
{
	public partial class Form1 : Form
	{
		public Form1()
		{
			InitializeComponent();

			init();
		}

		Network network;
		long handle; // network handle

		private void init()
		{
			network = new Network();
			network.SetHostName("localhost",1000);
			handle = network.Connect();
			if ( handle == 0 )
			{
				MessageBox.Show("Host接続に失敗");
			}

		}


		private void richTextBox2_KeyPress(object sender , KeyPressEventArgs e)
		{
			// 空ならば発言しない
			if ( richTextBox2.Text == "" )
				return;

			if ( e.KeyChar == '\r' ) // enter key
			{
				string text = richTextBox2.Text;
				richTextBox1.AppendText(text);
				richTextBox2.Text = "";

				byte[] data = new byte[64]; // 32文字まで

				MemoryCopy.SetString(data , 0 , text , 32);

				network.Write(handle , data);
			}
		}

		private void timer1_Tick(object sender , EventArgs e)
		{
			if ( handle != 0 )
			{
				byte[] data;
				network.Read(handle , out data);
				if ( data != null )
				{
					string s = MemoryCopy.GetString(data , 0 , 32);
					// 32文字まで

					richTextBox1.AppendText(s);
				}
			}
		}

		private void button1_Click(object sender , EventArgs e)
		{
			// 本当は、threadをまわして、そいつに処理させるべきだけど
			// サンプルなのでここにじかに書く。

			LinkedList<long> handles = new LinkedList<long>();
			Network network = new Network();
			network.SetHostName("localhost" , 1000);

			while ( true )
			{
				// listen

				{
					long handle;
					while ( ( handle = network.Listen() ) != 0 )
						handles.AddLast(handle);
				}

				// dispatch message
				{
					LinkedListNode<long> node = handles.First;
					while ( node != null )
					{
						byte[] data;
						if ( network.Read(node.Value , out data) != 0 )
						{
							// 切断しやがった
							LinkedListNode<long> next = node.Next;
							handles.Remove(node);
							node = next;
							continue;
						}

						// 送られてきたメッセージは
						// そのまま本人以外にbroadcastする。
						// (チャットサーバーなので)

						if ( data != null )
						{
							foreach ( long h in handles )
							{
								if ( h != node.Value )
									// 本人以外
									network.Write(h , data);
							}
						}

						node = node.Next;
					}
				}
			}
		}

	}
}