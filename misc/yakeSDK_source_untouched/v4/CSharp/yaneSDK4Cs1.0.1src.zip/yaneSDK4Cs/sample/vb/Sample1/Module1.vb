Imports y4cs.ytl
Imports y4cs.aux
Imports y4cs.timer
Imports y4cs.draw
Imports y4cs.sound


Module Module1

    Sub Main()
        Dim ca As New SoundLoader
        ca.loadDefRW(CodeConv.unicode_to_sjis("lupin1.ogg " & vbCrLf & " lupin2.ogg"))

        Dim screen As New Screen
        screen.setVideoMode(640, 480, 0)
        Dim fpstimer As New FpsTimer
        Dim fpslayer As New FpsLayer(fpstimer)

        Dim title As New String("���N�͂��������r�c�j�S�u�a�ł��񂪂�I")
        Dim font As New Font
        font.open(1, 400)   ' �����̂�400�~400�Ő���

        ' 1��������Texture�𐶐����Ă����B
        Dim textures As New vector
        Dim w As Char

        For Each w In title
            Dim t As New Texture
            t.setSurface(font.drawBlendedUnicode(w.ToString()))
            textures.push_back(t)
        Next

        ' �S���̕������\�������e�N�X�`���[
        font.open(1, 32) ' �����̂�32�~?�ōĐ���
        Dim texture2 As New Texture
        texture2.setSurface(font.drawBlendedUnicode(title))

        Dim state As Int32
        Dim moji As Int32
        Dim wait As Int32

        Do While GameFrame.pollEvent() = 0
            screen.clear()

            Select Case state
                Case 0
                    ca.play(0)
                    state = state + 1
                Case 1
                    screen.blendSrcAlpha()
                    screen.setColor(255, 0, 0)
                    screen.blt(CType(textures.Item(moji), Texture), 140, 40)
                    wait = wait + 1
                    If wait = 20 Then
                        wait = 0
                        moji = moji + 1
                        If textures.size() = moji Then
                            state = state + 1
                            Exit Select
                        End If
                        state = 0
                    End If
                Case 2
                    ca.play(1)
                    state = state + 1
                Case 3
                    screen.blendSrcAlpha()
                    If wait < 170 Then
                        screen.setColor(255, 0, 0)
                        screen.blt(texture2, 20, 200)
                    Else
                        Dim offset As Int32
                        Dim r As Int32
                        offset = wait - 170
                        r = 255 - offset * 8
                        If r < 0 Then
                            r = 0
                        End If
                        screen.setColor(r, 0, 0)
                        screen.blt(texture2, 20 - offset, 200)
                        screen.blt(texture2, 20 + offset, 200)
                    End If
                    wait = wait + 1
                    If wait = 300 Then
                        Return
                    End If
            End Select

            fpslayer.onDraw(screen, 400, 10)
            screen.update()
            fpstimer.waitFrame()
        Loop

    End Sub

End Module
