using System;
using y4cs.timer;
using y4cs.aux;
using y4cs.draw;
using y4cs.input;
using y4cs.task;
using y4cs.task.game;

class MyShip {
	public float x;
	public float y;
	public float width;
	public float height;
	public float speed;
	public int shotwait;
	
	public MyShip() {}

	public void Init(TCB cb, object info) {
		DeviceInfo di = info as DeviceInfo;

		width = 32;
		height = 32;

		x = (di.screen.getWidth() + width) / 2.0f;
		y = (di.screen.getHeight() + height) / 2.0f;
		speed = 4;
		shotwait = 4;

		// �ړ���
		cb.proc = new TaskProc(Move);
	}

	public void Move(TCB cb, object info) {
		DeviceInfo di = info as DeviceInfo;
		if (di.key.isPress((int)KeyCode.LEFT) ) 
			x -= speed;
		if (di.key.isPress((int)KeyCode.RIGHT) ) 
			x += speed;
		if (di.key.isPress((int)KeyCode.UP) ) 
			y -= speed;
		if (di.key.isPress((int)KeyCode.DOWN) ) 
			y += speed;

		if (x < 0) 
			x = 0;
		if (x > di.screen.getWidth() - width) 
			x = di.screen.getWidth() - width;
		if (y < 0) 
			y = 0;
		if (y > di.screen.getHeight() - height) 
			y = di.screen.getHeight() - height;
	}
}

public class MyBullet {
	public float x;
	public float y;
	public float dx;	// �ړ���x
	public float dy;	// �ړ���y

	public MyBullet(float x, float y, float dx, float dy) {
		this.x = x;
		this.y = y;
		this.dx = dx;
		this.dy = dy;
	}
}

public class Sample02 {
	// �^�X�N���X�g
	public static void Main() {

		// �����܂�̃p�^�[��
		Screen screen = new Screen();
		screen.beginScreenTest();
		screen.testVideoMode(640,480,0);
		screen.endScreenTest();

		screen.blendSrcAlpha();

		// KeyBoardInput key = new KeyBoardInput();

		// 60fps
		FpsTimer fpstimer = new FpsTimer();
		fpstimer.setFps(60);

		// FontLoader loader = new FontLoader();
		// loader.register("msmincho.ttc", 32);
		// Font font = loader.get(0) as Font;

		// �^�X�N�o�^
		// TaskController tc = new TaskController(new TaskList(256));
		// tc.add("���@", 1000, new TaskProc(new MyShip().Init));

		// DeviceInfo info = new DeviceInfo(screen, key, null);


		Surface bg = new Surface();
		Surface sp = new Surface();

		bg.load("bg.bmp");
		sp.load("sample22.bmp");

		// �J���[�L�[
		Color4ub k = new Color4ub(0, 0, 255, 255);
		// bg��sp��]��(�΂𔲂��F)
		bg.blt(sp, 0, 0, k);
		byte alpha = 64;
		bg.blt(sp, 0, 0, alpha);

		Color4ub c = sp.getPixel(289, 252);
		c = sp.getPixel(264, 128);

		// �e�N�X�`���[�ɐݒ�
		Texture tex = new Texture();
		tex.setSurface(bg);

		while (GameFrame.pollEvent() == 0) {
			screen.clear();
			// key.update();

			// �^�X�N��D��x���ɏ�������
			// tc.call(info);
			//tc.clean();
			screen.blt(tex, 0, 0);

			screen.update();
			fpstimer.waitFrame();
		}
	}
}
