using System;
using System.IO;
using y4cs.ytl;
using y4cs.aux;
using y4cs.math;
using y4cs.timer;
using y4cs.input;
using y4cs.draw;
using y4cs.sound;

namespace Test3
{
	class MonologueView {
		#region public

		public MonologueView(Screen screen_) {
			screen = screen_;
			key = new Key1();

			bFadeIn = false;
			bFadeOut = false;
			screen.setColor(0);
			screen.clear();
			bBlack = true;

			nTextPos = 480;
			nTextNext = 0;
			nTextLast = 0;
			nReadMessageCount = 0;
			nPosX = nPosY = 0;
			nCutCount = 0;
			nEnd = 0;

			BGPlane = new TextureVector();

			TextPlane = new Texture[32];
			for (int i = 0; i < TextPlane.Length; ++i) {
				TextPlane[i] = new Texture();
			}

			font = new Font();
			font.open(0, 28);

			timer = new Timer();

			BGMSound = new SoundLoader();
			BGMSound.loadDefRW(CodeConv.unicode_to_sjis("data/bgm31.mid,0,-1"));

		}
		
		/// <summary>
		/// ���m���[�O��ʕ`��
		/// </summary>
		/// <returns></returns>
		public virtual int OnDraw() {
			key.update();
			if (key.isPress(5)) {
				if (nEnd == 0)
					nEnd = 1;
			}
			if (nEnd != 0) {
				screen.setColor(256 - nEnd*256/10);
				nEnd++;
				if (nEnd == 10) {
					screen.setColor(256);
					BGMSound.stopBGMFade(1500);
				}
				if (nEnd == 30) {
					bEof = true;
				}
			}

			if (bFadeIn) {
				int dw = timer.get();
				dw = dw * 256 / 3000;	// 3�b
				if (dw > 256) {
					bFadeIn = false;
					dw = 256;
				}
				OnDrawBG((int)dw);
			}
			else if (bFadeOut) {
				int dw = timer.get();
				dw = dw * 256 / 3000;
				if (dw > 256) {
					bFadeOut = false;
					dw = 256;
					bBlack = true;
				}
				OnDrawBG((int)(256 - dw));
			}
			else {
				OnDrawBG();
			}

			nReadMessageCount++;
			if (nReadMessageCount == 7) {
				nReadMessageCount = 0;
				GetNextMessage();
			}
			return IsEof() ? 1 : 0;
		}

		/// <summary>
		/// �ǂݍ���
		/// </summary>
		/// <param name="filename"></param>
		/// <returns></returns>
		public virtual int Load(string filename) {
			try {
				file = new StreamReader(filename, System.Text.Encoding.Default);
			}
			catch (Exception e) {
				Console.WriteLine(e.Message);
				return -1;
			}
			bEof = false;
			GetNextMessage();
			return 0;
		}

		public bool IsEof() {
			return bEof;
		}

		# endregion

		# region protected

		protected Screen screen;

		protected KeyInputBase key;

		protected bool bEof;
		/// <summary>
		/// �t�F�[�h�C�����H
		/// </summary>
		protected bool bFadeIn;

		/// <summary>
		/// �t�F�[�h�A�E�g���H
		/// </summary>
		protected bool bFadeOut;

		/// <summary>
		/// 
		/// </summary>
		protected Timer timer;

		/// <summary>
		/// 
		/// </summary>
		protected void GetNextMessage() {
			if (bEof)
				return;
			while (true) {
				string s = file.ReadLine();
				if (s == null) {
					SetText(String.Empty);
					if (nEnd == 0) 
						nEnd = 1;
					return;
				}

				LineParser parser = new LineParser(s);
				string line = parser.getStr();
				if (line.IndexOf("//") >= 0)
					continue;	// �R�����g�s

				if (line.IndexOf("$black") >= 0) {
					screen.setColor(0);
					bBlack = true;
					continue;
				}

				if (line.IndexOf("$bgmfadeout") >= 0) {
					BGMSound.stopBGMFade(800);
					continue;
				}

				if (line.IndexOf("$bgmreset") >= 0) {
					BGMSound.stopBGM();
					continue;
				}

				if (line.IndexOf("$bgm") >= 0) {
					BGMSound.playBGM((int)parser.getNum(long.MaxValue));
					continue;
				}

				if (line.IndexOf("$bg3") >= 0) {
					for (int i = 0; i < 3; ++i) {
						s = parser.getStr();
						Texture t = new Texture();
						t.load(s);
						BGPlane.add(t, 0, i * 480);
					}
					BGPlane.update();
					bBlack = false;
					nPosY = 0;
					continue;
				}

				if (line.IndexOf("$bg") >= 0) {
					s = parser.getStr();
					Texture t = new Texture();
					t.load(s);
					BGPlane.add(t, 0, 0);
					BGPlane.update();
					bBlack = false;
					continue;
				}
				if (line.IndexOf("$music") >= 0) {
					s = parser.getStr();
					// �T�E���h����͂܂�
					continue;
				}
				if (line.IndexOf("$setfillcolor") >= 0) {
					int r, g, b;
					r = (int)parser.getNum(0);
					g = (int)parser.getNum(0);
					b = (int)parser.getNum(0);
					screen.setColor(r,g,b);
					continue;
				}
				if (line.IndexOf("$se") >= 0) {
					// SE���܂�
					continue;
				}
				if (line.IndexOf("$fadein") >=0) {
					bFadeIn = true;
					bFadeOut = false;
					timer.reset();
					continue;
				}
				if (line.IndexOf("$fadeout") >= 0){	//�@�t�F�[�h�A�E�g
					bFadeIn	=false;			//	�t�F�[�h�C�����H
					bFadeOut	=true;			//	�t�F�[�h�A�E�g���H
					timer.reset();
					continue;
				}
				if (line.IndexOf("$cutin") >= 0) {
					s = parser.getStr();
					CutPlane.enableAlpha();
					CutPlane.setColorKey(37,255,0);
					CutPlane.load(s);
					nCutX = (int)parser.getNum(0);
					nCutY = (int)parser.getNum(0);
					nCutCount = 16;
					continue;
				}
				if (line.IndexOf("$cutout") >= 0) {
					nCutCount = 256 + 16;
					continue;
				}
				SetText(line);
				break;
			}
		}

		/// <summary>
		/// 
		/// </summary>
		protected virtual void OnDrawBG() {
			OnDrawBG(256);
		}

		protected virtual void OnDrawBG(int nFadeLevel) {
			if (bBlack) {
				screen.clear();
			}
			else {
				Rect srcRect = new Rect();
				srcRect.left = 0;
				srcRect.top = nPosY;
				srcRect.right = 640;
				srcRect.bottom = srcRect.top + 480;
				if (nFadeLevel != 256) {
					screen.setColor((int)nFadeLevel);
					screen.enableBlend();
					screen.blendSrcAlpha();
					screen.blt(BGPlane, 0, 0, ref srcRect);
					screen.disableBlend();
				}
				else {
					screen.blt(BGPlane, 0, 0, ref srcRect);
				}
			}
			if (nCutCount > 0) {
				int nCut = nCutCount;
				if (nCut > 256) nCut = 512-nCut;
				if (nCutCount != 256)
					nCutCount += 16;
				if (nCutCount == 512)
					nCutCount = 0;

				screen.enableBlend();
				if (nCut == 256) {
					screen.blendSrcAlpha();
					screen.blt(CutPlane, nCutX, nCutY);
				}
				else {
					screen.setColor(nCut);
					screen.blendAddColorAlpha();
					screen.blt(CutPlane, nCutX, nCutY);
					screen.resetColor();
				}
				screen.disableBlend();
			}

			// �e�L�X�g�`��
			screen.enableBlend();
			screen.blendSrcAlpha();
			for (int i = 0; i < TextPlane.Length; ++i) {
				screen.setColor(69, 79, 16);
				screen.blt(TextPlane[(i+nTextLast)%32],32+2,nTextPos+i*28+2);
				screen.setColor(180);
				screen.blt(TextPlane[(i+nTextLast)%32],32,nTextPos+i*28);
			}
			screen.resetColor();
			screen.disableBlend();
			nTextPos -= 4;
			nPosY++;
			if (nPosY > 480*2)
				nPosY = 480*2;

		}

		/// <summary>
		/// 
		/// </summary>
		protected StreamReader file;

		/// <summary>
		/// 
		/// </summary>
		protected bool bBlack;

		/// <summary>
		/// 
		/// </summary>
		protected Font font;

		/// <summary>
		/// 
		/// </summary>
		protected SoundLoader BGMSound;

		/// <summary>
		/// BG*3
		/// </summary>
		protected TextureVector BGPlane;

		/// <summary>
		/// BG�\�����W
		/// </summary>
		protected int nPosX, nPosY;

		/// <summary>
		/// �z��Text
		/// </summary>
		protected Texture[] TextPlane;

		/// <summary>
		/// �e�L�X�g�\���|�W�V����
		/// </summary>
		protected int nTextPos;

		/// <summary>
		/// ���Ɏg��TextPlane
		/// </summary>
		protected int nTextNext;

		/// <summary>
		/// �ŏ��̃e�L�X�g
		/// </summary>
		protected int nTextLast;

		/// <summary>
		/// �e�L�X�g�̐ݒ�
		/// </summary>
		/// <param name="text"></param>
		protected void SetText(string text) {
			TextPlane[nTextNext].setSurface(font.drawBlendedUnicode(text));

			nTextNext++;
			if (nTextNext == 32) {
				nTextNext = 0;
			}
			if (nTextPos < -32) {
				nTextPos += 28;
				nTextLast++;
				if (nTextLast == 32) {
					nTextLast = 0;
				}
			}
		}

		/// <summary>
		/// ���̃��b�Z�[�W
		/// </summary>
		protected int nReadMessageCount;

		/// <summary>
		/// Cut in/out����v���[��
		/// </summary>
		protected Texture CutPlane = new Texture();

		/// <summary>
		/// ���̃J�E���^
		/// </summary>
		protected int nCutCount;

		protected int nCutX, nCutY;

		/// <summary>
		/// �I���J�E���^
		/// </summary>
		protected int nEnd;

		# endregion
	}


	/// <summary>
	/// App �̊T�v�̐����ł��B
	/// </summary>
	class App
	{
		/// <summary>
		/// �A�v���P�[�V�����̃��C�� �G���g�� �|�C���g�ł��B
		/// </summary>
		[STAThread]
		static void Main(string[] args)
		{
			Screen screen = new Screen();

			screen.beginScreenTest();
			screen.testVideoMode(640,480,0);
			screen.endScreenTest();

			FpsTimer fpstimer = new FpsTimer();
			fpstimer.setFps(20);

#if false
			for (int i = 0; i < 100; ++i) {
				Font font = new Font();
				font.open(0, 28);
				font.close();
				System.Threading.Thread.Sleep(100);
			}
			


#else

			MonologueView mv = new MonologueView(screen);
			mv.Load("data/opening.txt");
			while (GameFrame.pollEvent() == 0) {
				screen.clear();
				if (mv.OnDraw() != 0)
					break;
				screen.update();
				fpstimer.waitFrame();
			}
#endif
		}
	}
}


