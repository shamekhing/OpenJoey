using System;
using y4cs.aux;
using y4cs.timer;
using y4cs.draw;

namespace Sample6
{
	/// <summary>
	/// Class1 �̊T�v�̐����ł��B
	/// </summary>
	class App {
		public delegate void TransFunc(Screen screen, ITextureBase texture, int x, int y, int z);

		/// <summary>
		/// �A�v���P�[�V�����̃��C�� �G���g�� �|�C���g�ł��B
		/// </summary>
		[STAThread]
		static void Main(string[] args) {
			Screen screen = new Screen();
			screen.setVideoMode(640,480,0);

			Texture t = new Texture();
			t.load("syugoo.jpg");

			FpsTimer fpstimer = new FpsTimer();
			fpstimer.setFps(int.MaxValue); // no wait
			FpsLayer fpslayer = new FpsLayer(fpstimer);

			Timer timer = new Timer();

			int no = 0; // �g�����W�V�����i���o�[

			TransFunc[] transfunc = {
										new TransFunc(TransBltter.bltSlitCurtain1),
										new TransFunc(TransBltter.bltSlitCurtain2),
										new TransFunc(TransBltter.bltSlitCurtain3),
										new TransFunc(TransBltter.bltSlitCurtain4),
										new TransFunc(TransBltter.bltSlitCurtain5),
										new TransFunc(TransBltter.bltSlitCurtain6),
										new TransFunc(TransBltter.bltSlitCurtain7),
										new TransFunc(TransBltter.bltSlitCurtain8),
										new TransFunc(TransBltter.bltCircle1),
										new TransFunc(TransBltter.bltCircle2),
										new TransFunc(TransBltter.bltCircle3),
										new TransFunc(TransBltter.bltCircle4),
										new TransFunc(TransBltter.bltCircle5),
										new TransFunc(TransBltter.bltWhorl1),
										new TransFunc(TransBltter.bltWhorl2),
										new TransFunc(TransBltter.bltWhorl3),
										new TransFunc(TransBltter.bltWhorl4),
										new TransFunc(TransBltter.bltWhorl5),
										new TransFunc(TransBltter.bltWhorl6)
									};

			while (GameFrame.pollEvent() == 0){
				screen.setClearColor(255,255,255);
				screen.clear();
				int phase = (int)timer.get()*255/2000; // 2�b��255��
				if (phase > 255) {
					no++; phase = 0; timer.reset();
					if (no==transfunc.Length) no = 0;
				}

				transfunc[no](screen,t,0,0,phase);
				fpslayer.onDraw(screen,500,30);
				screen.update();
				fpstimer.waitFrame();
			}
		}

	}
}

