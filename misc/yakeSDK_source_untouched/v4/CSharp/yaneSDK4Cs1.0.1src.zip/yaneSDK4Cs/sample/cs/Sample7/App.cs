﻿using System;
using System.IO;
using y4cs.ytl;
using y4cs.aux;
using y4cs.timer;
using y4cs.math;
using y4cs.draw;
using y4cs.sound;
using y4cs.input;

namespace Sample7 {

	interface IPlay {
		int time();
		bool isPress(int k);
		bool update();
		void close();
	}

	class Play : IPlay {
		Key2 key;
		FixTimer timer;
		BinaryWriter bw;

		public Play() {
			key = new Key2();
			bw = new BinaryWriter(File.Create("replay.dat"));
		}

		#region IPlayer メンバ

		public int time() {
			return timer.get();
		}

		public bool isPress(int k) {
			return key.isPress(k);
		}

		public bool update() {
			if (timer == null) {
				timer = new FixTimer();
				timer.reset();
			}
			else {
				timer.update();
			}
			key.update();
			bw.Write(timer.get());

			byte state = 0;
			for (int i = 0; i <= 5; ++i) {
				if (key.isPress(i)) {
					state |= (byte)(1 << i);
				}
			}
			bw.Write(state);
			return true;
		}

		public void close() {
			if (bw != null) {
				bw.Close();
				bw = null;
			}
		}

		#endregion

	}

	class Replay : IPlay {
		BinaryReader br;
		byte key;
		int tm;

		public Replay(string filename) {
			br = new BinaryReader(File.Open(filename, FileMode.Open));
			key = 0;
			tm = 0;
		}

		#region IPlayer メンバ

		public int time() {
			return tm;
		}

		public bool isPress(int k) {
			return (key & (1 << k)) != 0;
		}

		public bool update() {
			if (br.PeekChar() == -1) {
				return false;
			}
			tm = br.ReadInt32();
			key = br.ReadByte();
			return true;
		}

		public void close() {
			if (br != null) {
				br.Close();
				br = null;
			}
		}

		#endregion

	}

	/// <summary>
	/// App の概要の説明です。
	/// </summary>
	class App {
		static Rand rand;
		static int level;		//	ゲームレベル

		struct Tama {
			public float x,y;	 //	座標
			public float vx,vy; // 速度ベクトル
			public float speed; // 移動速度(vx,vyはこれで正規化される)
			public float ax,ay; // 加速度ベクトル
			public float spin;	 // 追尾度
			public bool alive;	 // この弾の生存フラグ
			public int r,g,b;

			public void reset() { alive = false; }
			public void setColor(int r_,int g_,int b_) { r = r_; g = g_; b = b_; }
			public void move(float x_,float y_){
				if (!alive) return ;
				// vx,vyを正規化する
				float v_dist = (float)Math.Sqrt(vx*vx + vy*vy);
				if (v_dist < 0.1) return ; // 正規化できナー
				vx = vx / v_dist * speed; vy = vy / v_dist * speed;
				x += vx; y += vy;
				vx += ax; vy += ay;
				float ax_ = (x_-x);
				float ay_ = (y_-y);
				// ax_,ay_を正規化して、spinを掛ける
				float a_dist = (float)Math.Sqrt(ax_*ax_ + ay_*ay_);
				ax_ = ax_ / a_dist * spin;
				ay_ = ay_ / a_dist * spin;
				ax += ax_; ay += ay_;

				//	画面範囲外に消えたら死亡(ただし、画面外のト音記号の発射した♪が
				//	到達できるように配慮する
				if (x < -100 || y < -200 || x > 640+100 || y > 480+200) alive = false;
			}
			public void reflect(float x_,float y_){
				//	(x_,y_)と反対方向にふっとぶ
				vx = x-x_;
				vy = y-y_;
				float v_dist = (float)Math.Sqrt(vx*vx + vy*vy);
				if (v_dist < 0.1) return ; // 正規化できナー
				vx = vx / v_dist;
				vy = vy / v_dist;
				speed = speed*4;
			}

			public void onDraw(Screen dst,Texture src){
				if (!alive) return ;
				dst.setColor(r,g,b);
				dst.blt(src,(int)x-16,(int)y-20);
				//	判定位置は、ハートのLOVEのOとVとの間と、
				//	♪のおたまじゃくしのところ
			}
			public void set(float x_,float y_,float vx_,float vy_,float ax_,float ay_
				,float spin_,float speed_){
				x = x_; y = y_;
				vx = vx_; vy = vy_; ax = ax_; ay = ay_; spin = spin_;
				speed = speed_;
				setColor((int)rand.get(128),(int)rand.get(128),(int)rand.get(128));
				alive = true;
			}
		}

		const int tama_max = 256;
		const float speed  = 4;  // 弾のスピード

		static int search(Tama[] tama){
			//	空き番を返す。なければ-1。
			for(int i=0;i<tama_max;++i){
				if (!tama[i].alive) return i;
			}
			return -1;
		}

		static void shot(Tama[] tama,float from_x,float from_y,float to_x,float to_y,int type){
			int n = search(tama);
			if (n==-1) return ;

			float vx = to_x - from_x;
			float vy = to_y - from_y;
			//	vx,vyを正規化
			float dist = (float)Math.Sqrt(vx*vx + vy*vy);
			if (dist<0.1) return ;
			vx/=dist; vy/=dist;
			vx *= speed; vy *= speed;

			int way = 0;
			switch (type) {
				case 1: // level way 方向固定
					int step = 512/level;
					way = step;
					for(int i=0;i<level;++i) {
						tama[n].set(from_x,from_y,SinTable.get().cos(way),SinTable.get().sin(way),0,0,0,speed);
						n = search(tama); if (n==-1) return ;
						way += step;
					}
					break;
				case 2:	// 誘導 5way
					try {
						way = SinTable.get().atan((int)vx,(int)vy) >> 7; // 65536/512
					} catch (y4cs_error) {
					}
					tama[n].set(from_x,from_y,SinTable.get().cos(way+0),SinTable.get().sin(way+0),0,0,0.005f,speed);
					n = search(tama); if (n==-1) return ;
					tama[n].set(from_x,from_y,SinTable.get().cos(way+30),SinTable.get().sin(way+50),0,0,0.005f,speed);
					n = search(tama); if (n==-1) return ;
					tama[n].set(from_x,from_y,SinTable.get().cos(way-30),SinTable.get().sin(way-50),0,0,0.005f,speed);
					if (level <= 25) return ; // level 25以下なら3way
					n = search(tama); if (n==-1) return ;
					tama[n].set(from_x,from_y,SinTable.get().cos(way+60),SinTable.get().sin(way+100),0,0,0.005f,speed);
					n = search(tama); if (n==-1) return ;
					tama[n].set(from_x,from_y,SinTable.get().cos(way-60),SinTable.get().sin(way-100),0,0,0.005f,speed);
					break;
				case 0:	// 5way
					try {
						way = SinTable.get().atan((int)vx,(int)vy) >> 7; // 65536/512
					} catch (y4cs_error) {
					}
					tama[n].set(from_x,from_y,SinTable.get().cos(way+0),SinTable.get().sin(way+0),0,0,0,speed);
					n = search(tama); if (n==-1) return ;
					tama[n].set(from_x,from_y,SinTable.get().cos(way+30),SinTable.get().sin(way+30),0,0,0,speed);
					n = search(tama); if (n==-1) return ;
					tama[n].set(from_x,from_y,SinTable.get().cos(way-30),SinTable.get().sin(way-30),0,0,0,speed);
					if (level <= 15) return ; // level 15以下なら3way
					n = search(tama); if (n==-1) return ;
					tama[n].set(from_x,from_y,SinTable.get().cos(way+60),SinTable.get().sin(way+60),0,0,0,speed);
					n = search(tama); if (n==-1) return ;
					tama[n].set(from_x,from_y,SinTable.get().cos(way-60),SinTable.get().sin(way-60),0,0,0,speed);
					break;
				case 3: // 32 way 方向固定
					int ways = 32;
					if (level < 20) ways /= 2;
					if (level < 10) ways /= 2;
					step = 512/ways;
					way = step;
					for(int i=0;i<ways;++i) {
						tama[n].set(from_x,from_y,SinTable.get().cos(way),SinTable.get().sin(way),0,0,0,speed);
						n = search(tama); if (n==-1) return ;
						way += step;
					}
					break;
			}
		}

		static bool isCross(float x1,float y1,float x2,float y2,float w,float h){
			//	(x1,y1)を左上とする、幅w,高さhの矩形に(x2,y2)が含まれればtrueを返す
			return	(x1 < x2) && (x2 < x1 + w) &&
				(y1 < y2) && (y2 < y1 + h);
		}


		/// <summary>
		/// アプリケーションのメイン エントリ ポイントです。
		/// </summary>
		[STAThread]
		static int Main(string[] args) {
			try {
				FpsTimer fpsTimer = new FpsTimer();
				fpsTimer.setFps(60);

				Screen screen = new Screen();
				screen.setCaption("♪ゲー");
				screen.setIcon("heart.png");

				IPlay play;

				screen.beginScreenTest();	//	いまからスクリーンテストをする
				screen.testVideoMode(640,480,0);	// ウィンドゥモード 640×480をテスト
				screen.endScreenTest();	//	テスト終了


				FixTimer time = new FixTimer();

				rand = new Rand();
				Key2 key = new Key2();

				MouseInput mouse = new MouseInput();
				mouse.hide();	//	マウスカーソル消しておく

				//	Texture texture = new Texture;
				//	texture.load("Star.gif");

				Texture heart = new Texture();
				heart.load("heart.png");

				Texture onpu = new Texture();
				onpu.setColorKeyPos(0,0);
				onpu.load("onpu.gif");

				Texture touon = new Texture();
				touon.load("touon.png");

				//	20fps * 60sec * 5
				byte[] /* [20*60*5]*/ timing_data;
				timing_data = (byte[])FileSys.read("timingdata.bin");


				Sound bgm = new Sound();
				bgm.load("nyokiMIX_de44.ogg",0);

				float[] tx,ty; // ト音記号ちゃん
				tx = new float[4];
				ty = new float[4];
				int[] ton = new int[4]; 	// ト音記号ちゃんの♪発射後のフェードレート

				float x,y;	//	自機の位置(ハート)

				Tama[] tama = new Tama[tama_max];

				int last_scan;	// 前回、弾発射を検査した位置
				int score;	// スコア
				int myleft; // 残り機数
				int highscore = 0; // ハイスコア
				bool gameover;
				int deadtime; // 死亡後の処理時間
				int charge;   // スペースキーでの貯め
				int bx=0,by=0,br=0,bc=0,bn=0;	// 倍率の表示
				int extend;		//	自機のextend
				bool charged;	// チャージ中か

			replay:;				
				if (args.Length == 0)
					play = new Play();
				else
					play = new Replay(args[0]);

				charged = false;
				extend = 500000;
				bc = bn = 0;
				charge = 0;
				deadtime = 0;
				gameover = false;
				myleft = 3;
				score = 0;
				last_scan = 0;
				x = 320; y = 240;
				tx[0] = -touon.getWidth(); ty[0] = 0;
				tx[1] = 640; ty[1] = 480-touon.getHeight();
				tx[2] = 0; ty[2] = 480;
				tx[3] = 640-100; ty[3] = -touon.getHeight();
				ton[0] = ton[1] = ton[2] = ton[3] = 0;
				for(int i=0;i<tama.Length;++i) tama[i].reset();
				level = 0;

				bgm.play();

				while (GameFrame.pollEvent() == 0){
					// isPress(0)だけ特別扱い
					key.update();
					if (key.isPress(0)) break;
					if (gameover) {
						//	enter key で replay
						play.close();
						if (key.isPush(6)) { goto replay; }
						goto moveSkip;
					}
					play.update();

					level = 1 + (int)(play.time()/10000); {
															 float dist = 4.0f; // 一回の移動可能距離
															 float vx=0,vy=0;
															 if (play.isPress(1)) { vy = -dist; }
															 if (play.isPress(2)) { vy = +dist; }
															 if (play.isPress(3)) { vx = -dist; }
															 if (play.isPress(4)) { vx = +dist; }
															 if (vx!=0 && vy!=0) { vx*=0.7f; vy*=0.7f; }	//	斜め移動のペナルティ

															 if (play.isPress(5)) { ++charge; charged = true; } else {
																 //	chargeの量に応じて、弾を反射
																 if (charge != 0){
																	 int num = (charge+59)/60;
																	 if (num>=2) {
																		 float d = 1 << (num>20?25:(num+6)); // 判定矩形サイズ
																		 bn = 0;
																		 for(int i=0;i<tama.Length;++i){
																			 if (!tama[i].alive) continue;
																			 if (isCross(tama[i].x-d/2,tama[i].y-d/2,x,y,d,d)){
																				 tama[i].reflect(x,y); // 跳ね返す
																				 score += 200 * num;
																				 ++bn;
																				 // 跳ね返したのに比例してスコアが入る
																			 }
																		 }
																		 bx = (int)x; by = (int)y; br = num; bc = 60;
																	 }
																	 charge = 0; charged = false;
																 } else {
																	 //	no chargeなのでscoreをtimeに比例して加算
																	 //				score += ft/100;
																 }
															 }
															 if (charge == 0) { vx*=2; vy*=2; }

															 x+=vx; y+=vy;
															 if (x<0) x = 0;
															 if (x>640) x = 640;
															 if (y<0) y = 0;
															 if (y>480) y = 480;
														 }

					//	ト音記号の移動
					tx[0]+=2; if (tx[0]>640) tx[0] = -touon.getWidth();
					tx[1]-=2; if (tx[1]<0-touon.getWidth()) tx[1] = 640;
					ty[2]+=2; if (ty[2]>480) ty[2] = -touon.getHeight();
					ty[3]-=2; if (ty[3]<0-touon.getHeight()) ty[3] = 480;

					for(int i=0;i<tama.Length;++i) tama[i].move(x,y);

					//	弾発生
					int t = (int)(play.time()*0.02);

					for(int i=0;i<4;++i) ton[i] = 0;

					//	フレームスキップを考慮して、発射されるはずであった弾をサーチ
					for(;last_scan<t;++last_scan){
						// ひとつ前で押されていなくて、今回押されているの意味
						byte d = (byte)(timing_data[last_scan+1] & ~timing_data[last_scan]);
						int w = (int)touon.getWidth()/2 , h = (int)touon.getHeight()/2;
						if ((d & 1) != 0) { //key.isPress(5)) {
							shot(tama,tx[0]+w,ty[0]+h,x+50,y+40,0);
						}
						if ((d & 2) != 0) { //key.isPress(6)) {
							shot(tama,tx[1]+w,ty[1]+h,x+50,y+40,1);
						}
						if ((d & 4) != 0) { // key.isPress(7)) {
							shot(tama,tx[2]+w,ty[2]+h,x+50,y+40,2);
						}
						if ((d & 8) != 0) { // key.isPress(8)) {
							shot(tama,tx[3]+w,ty[3]+h,x+50,y+40,3);
						}
						//	♪発射フェーズでは、ト音記号を暗くする
						byte d2 = timing_data[last_scan];
						if ((d & 1) != 0) ton[0] = 128;
						if ((d & 2) != 0) ton[1] = 128;
						if ((d & 4) != 0) ton[2] = 128;
						if ((d & 8) != 0) ton[3] = 128;
					}
					score += 10; {
									 /*
										 ト音記号と重なるとスコアあーぷ！とか
									 */
									 int w = (int)touon.getWidth(), h = (int)touon.getHeight();
									 for(int i=0;i<4;++i){
										 if (isCross(tx[i],ty[i],x,y,w,h)) {
											 //	score += 1000; // もりもりアップ!
											 if (charged) charge+=2; // チャージ中なら高速チャージ
										 }
									 }
								 }

					//	当たり判定
					if (deadtime == 0) {
						const float d = 10.0f; // 判定矩形サイズ
						for(int i=0;i<tama.Length;++i){
							if (!tama[i].alive) continue;
							if (isCross(tama[i].x-d/2,tama[i].y-d/2,x,y,d,d)){
								deadtime = 100; // 死亡カウント
							}
						}
					} else {
						if (--deadtime == 0){
							--myleft; // 死亡
							charge = 200; // 復活サービス
						}
					}

					if (myleft < 0) {
						gameover = true;
						bgm.stop();
					}

					if (bc != 0) --bc;

					//	----- ↑↑ 遅いマシンでも移動処理だけは保証する
				moveSkip:;

					fpsTimer.waitFrame();
					if (fpsTimer.toBeSkip()) continue; // 描画キャンセル

					screen.setClearColor(255,255,255);
					screen.clear();
					screen.blendSrcAlpha();
					//		screen.disableBlend();
					//	自機のextend (every 500000)
					if (score > extend) { ++myleft;
						extend+=500000;
					}

					//	残機
					Size hs = new Size();
					Rect r = new Rect();
					hs.setSize((int)heart.getWidth()/2,(int)heart.getHeight()/2);
					screen.setColor(255,255,255);
					for(int i=0;i<myleft;++i){
						screen.blt(heart,(int)(i*heart.getWidth()/2),50,ref r,ref hs);
					}

					//	ト音記号の描画
					float faderate = (float)(SinTable.get().cos0_1((int)(play.time()/4)));
					float fade127 = faderate*127;
					for(int i=0;i<4;++i){
						int tn = ton[i];
						screen.blendSrcAlpha();
						switch(i) {
							case 0: goto case 1;
							case 1:
								screen.setColor((int)(128+fade127-tn),(int)(128+fade127-tn),(int)(128+fade127-tn)); break;
							case 2: screen.setColor((int)(128+fade127-tn),0,0); break;
							case 3: screen.setColor(0,0,(int)(128+fade127-tn)); break;
						}
						screen.blt(touon,(int)tx[i],(int)ty[i]);
					}

					//	自機
					if (!gameover){
						screen.setColor(255,255,255);
						if (deadtime == 0){
							screen.blt(heart,(int)x-50,(int)y-40); // ハートの中心が指定座標となるように
							if (charge != 0) {
								Size s = new Size();
								Rect dmy = new Rect();
								s.setSize((int)(heart.getWidth()/4),(int)(heart.getHeight()/4));
								int offset = (int)play.time()/2; // 小さなハートくるくるまわす
								int num = (charge+59)/60; // 小さなハートの数
								if (num>10) num = 10;
								for(int i=0;i<num && i<10;++i) {
									float xx = SinTable.get().cos((i*512)/num+offset)>>10;
									float yy = SinTable.get().sin((i*512)/num+offset)>>10;
									screen.blt(heart,(int)(x-50/4+xx),(int)(y-40/4+yy),ref dmy,ref s);
								}
							}
						} else {
							Size s = new Size();
							Rect dmy = new Rect();
							s.setSize((int)(heart.getWidth()*deadtime/100),(int)(heart.getHeight()*deadtime/100));
							screen.blt(heart,(int)(x-50*deadtime/100),(int)(y-40*deadtime/100),ref dmy,ref s);
						}
					}

					//	♪の描画
					screen.blendSrcAlpha();
					for(int i=0;i<tama.Length;++i) tama[i].onDraw(screen,onpu);

					screen.setColor(0,0,200);
					screen.setLineWidth(5);
					screen.drawString(StringConv.toConvHelpperU(score,10,8,' '),10,10,30);

					//		if (!bgm.isPlay()) break;
					if (play.time() >= 1000 * ( 60*4 + 2 + 5)) {
						//	goto replay; // 曲end
						if (!gameover) {
							gameover = true;
							extend = int.MaxValue; // extendしない
							score = score * 2 + myleft * 1000000;
						}
					}

					if (highscore < score) highscore = score;

					screen.setColor(0,200,0);
					screen.drawString(StringConv.toConvHelpperU(highscore,10,8,' '),320,10,30);

					if (bc != 0) {
						screen.setColor(255,0,0);
						screen.drawString(StringConv.toDec(bn) + "x" + StringConv.toDec(br),bx,by-50,30);
					}

					time.update();
					screen.update();
				}

			} catch (Exception e) {
				Console.WriteLine("例外が発生 : {0}", e.Message);
			}
				
			return 0;
		}
	}
}


