using System;
using System.Collections;
using System.Collections.Specialized;
using System.Text;
using System.Text.RegularExpressions;
using y4cs.draw;

namespace y4cs.text {
	public class HtmlColor {
		public static Color4ub Parse(string text) {
			byte r, g, b;
			r = g = b = 0;

			Regex re = new Regex(@"#(\w\w)(\w\w)(\w\w)");
			if (re.IsMatch(text)) {
				Match m = re.Match(text);
				try {
					r = Convert.ToByte(m.Groups[1].Value, 16);
					g = Convert.ToByte(m.Groups[2].Value, 16);
					b = Convert.ToByte(m.Groups[3].Value, 16);
				}
				catch (Exception) {
					r = g = b = 0;
				}				
			}
			return new Color4ub(r, g, b, 255);
		}
	}

	public class HtmlToken {
		string tag;
		string text;
		StringDictionary options;

		public HtmlToken(string tag) : this(tag, "") {}
		public HtmlToken(string tag, string text) {
			this.tag = tag.ToLower();
			this.text = text;
			options = new StringDictionary();
		}

		public string Tag {
			get { return tag; }
		}

		public string Text {
			get { return text; }
		}

		public StringDictionary Options {
			get { return options; }
		}

		public override string ToString() {
			return tag;
		}
	}

	public class HtmlTokenizer : IEnumerable {
		string target;
		ArrayList token = new ArrayList();

		public HtmlTokenizer(string text) {
			target = text;
			Tokenize();
		}

		public IEnumerator GetEnumerator() {
			return token.GetEnumerator();
		}

		public HtmlToken this [int index] {
			get { return (HtmlToken)token[index]; }
		}

		public int Count {
			get { return token.Count; }
		}

		private void Tokenize() {
			int pos = 0;
			string pattern = @"^<(/?\w+)(?:\s(\w+)\s*=\s*(?:"")?([^>=""]+)(?:"")?)*>";
			Regex re = new Regex(pattern, RegexOptions.IgnoreCase | RegexOptions.Compiled);
			StringBuilder sb = new StringBuilder();

			while (true) {
				// ��͏I��
				if (pos >= target.Length) {
					if (sb.Length > 0) {
						token.Add(new HtmlToken("", sb.ToString()));
						sb.Length = 0;
					}
					break;
				}

				string s = target.Substring(pos);
				if (re.IsMatch(s)) {
					if (sb.Length > 0) {
						token.Add(new HtmlToken("", sb.ToString()));
						sb.Length = 0;
					}
					Match m = re.Match(s);
					HtmlToken t = new HtmlToken(m.Groups[1].Value);
					if (m.Groups.Count == 4) {
						CaptureCollection keys = m.Groups[2].Captures;
						CaptureCollection vals = m.Groups[3].Captures;
						for (int i = 0; i < m.Groups[2].Captures.Count; ++i) 
							t.Options[keys[i].Value] = vals[i].Value;
					}
					token.Add(t);
					pos += m.Length;
				}
				else {
					sb.Append(target[pos++]);
				}
			}
		}
	}
}