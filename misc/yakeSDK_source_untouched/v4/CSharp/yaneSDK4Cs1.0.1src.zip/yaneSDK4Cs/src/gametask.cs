using System;
using y4cs.draw;
using y4cs.input;

namespace y4cs.task.game
{
	public class DeviceInfo {
		public Screen screen;
		public KeyBoardInput key;
		public MouseInput mouse;

		public DeviceInfo(Screen screen, KeyBoardInput key, MouseInput mouse) {
			this.screen = screen;
			this.key = key;
			this.mouse = mouse;
		}
	}
}
