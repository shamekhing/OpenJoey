using System;
using System.Collections;
using System.Collections.Specialized;

namespace y4cs.ytl {
	/// <summary>
	/// Singleton �̊T�v�̐����ł��B
	/// </summary>
	public sealed class Singleton {
		private static HybridDictionary instance = new HybridDictionary();

		private Singleton() {}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="t"></param>
		/// <returns></returns>
		public static object getInstance(Type t) {
			object o = instance[t];
			if (o == null) {
				lock(instance.SyncRoot) {
					o = instance[t];
					if (o == null) {
						o = Activator.CreateInstance(t);
						instance[t] = o;
					}
				}
			}
			return o;
		}
	}
}
			