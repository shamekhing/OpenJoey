using System;
using System.Collections;

namespace y4cs.ytl
{
	/// <summary>
	/// C++��STL��list�̂悤�ȃN���X�B
	/// </summary>
	
	public class list : IEnumerable
	{
		/// <summary>
		/// 
		/// </summary>
		/// <param name="x"></param>
		public void push_front(object x) {
			list_element first = endnode.next;
			list_element l = new list_element(x, endnode, first);
			first.prev = l;
			endnode.next = l;
			++s;
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="x"></param>
		public void push_back(object x) {
			list_element last = endnode.prev;
			list_element l = new list_element(x, last, endnode);
			last.next = l;
			endnode.prev = l;
			++s;
		}

		/// <summary>
		/// 
		/// </summary>
		/// <returns></returns>
		public object pop_front() {
			list_element first = endnode.next;
			list_element second = first.next;
			endnode.next = second;
			second.prev = endnode;
			if (s>=1) --s;
			return first.x;
		}

		/// <summary>
		/// 
		/// </summary>
		/// <returns></returns>
		public object pop_back() {
			list_element last = endnode.prev;
			list_element booby = last.prev;
			endnode.prev = booby;
			booby.next = endnode;
			if (s>=1) --s;
			return last.x;
		}

		/// <summary>
		/// 
		/// </summary>
		/// <returns></returns>
		public object front() {
			return endnode.next.x;
		}

		/// <summary>
		/// 
		/// </summary>
		/// <returns></returns>
		public object back() {
			return endnode.prev.x;
		}

		/// <summary>
		/// 
		/// </summary>
		/// <returns></returns>
		public iterator begin() {
			return new iterator(endnode.next);
		}

		/// <summary>
		/// 
		/// </summary>
		/// <returns></returns>
		public iterator end() {
			return new iterator(endnode);
		}

		/// <summary>
		/// 
		/// </summary>
		/// <returns></returns>
		public reverse_iterator rbegin() {
			return new reverse_iterator(endnode.prev);
		}

		/// <summary>
		/// 
		/// </summary>
		/// <returns></returns>
		public reverse_iterator rend() {
			return new reverse_iterator(endnode);
		}

		/// <summary>
		/// 
		/// </summary>
		public void erase() {
			endnode.prev = endnode.next = endnode;
			s = 0;
		}

		/// <summary>
		/// 
		/// </summary>
		/// <returns></returns>
		public int size() {
			return s;
		}

		/// <summary>
		/// 
		/// </summary>
		/// <returns></returns>
		public bool empty() {
			return s == 0;
		}

		/// <summary>
		/// 
		/// </summary>
		/// <returns></returns>
		public IEnumerable reverse() {
			return new reverse_list(endnode, s);
		}

		/// <summary>
		/// 
		/// </summary>
		public list() {
			endnode = new list_element();
			erase();
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="e"></param>
		/// <param name="s"></param>
		public list(list_element e, int s) {
			endnode = e;
			this.s = s;
		}

		/// <summary>
		/// 
		/// </summary>
		public class iterator : IEnumerator {
			/// <summary>
			/// 
			/// </summary>
			public iterator() {}

			/// <summary>
			/// 
			/// </summary>
			/// <param name="e"></param>
			public iterator(list_element e) { this.e = e; Reset(); }

			/// <summary>
			/// 
			/// </summary>
			/// <param name="it"></param>
			public iterator(iterator it) { e = it.e; Reset(); }

			/// <summary>
			/// 
			/// </summary>
			public object value { 
				get { return i.x;} 
				set { i.x = value;}
			}

			/// <summary>
			/// 
			/// </summary>
			/// <param name="it"></param>
			/// <returns></returns>
			public static iterator operator++(iterator it) {
				it.inc(); return it;
			}

			/// <summary>
			/// 
			/// </summary>
			/// <param name="it"></param>
			/// <returns></returns>
			public static iterator operator--(iterator it) {
				it.dec(); return it;
			}

			/// <summary>
			/// 
			/// </summary>
			/// <param name="a"></param>
			/// <param name="b"></param>
			/// <returns></returns>
			public static bool operator==(iterator a, iterator b) {
				return a.i == b.i;
			}

			/// <summary>
			/// 
			/// </summary>
			/// <param name="a"></param>
			/// <param name="b"></param>
			/// <returns></returns>
			public static bool operator!=(iterator a, iterator b) {
				return a.i != b.i;
			}

			/// <summary>
			/// 
			/// </summary>
			/// <param name="obj"></param>
			/// <returns></returns>
			public override bool Equals(object obj) {
				iterator it = obj as iterator;
				return this.e == it.e && this.i == it.i;
			}

			/// <summary>
			/// 
			/// </summary>
			/// <returns></returns>
			public override int GetHashCode() {
				return e.GetHashCode() ^ i.GetHashCode();
			}

			/// <summary>
			/// 
			/// </summary>
			private void inc() { if (i != null) i = i.next; }

			/// <summary>
			/// 
			/// </summary>
			private void dec() { if (i != null) i = i.prev; }

			/// <summary>
			/// 
			/// </summary>
			private list_element e;

			/// <summary>
			/// 
			/// </summary>
			private list_element i;

			#region IEnumerator �����o

			/// <summary>
			/// 
			/// </summary>
			public void Reset() {
				i = e;
			}

			/// <summary>
			/// 
			/// </summary>
			public object Current {
				get { return i.x;}
			}

			/// <summary>
			/// 
			/// </summary>
			/// <returns></returns>
			public bool MoveNext() {
				if (i.next == e)
					return false;
				i = i.next;
				return true;
			}

			#endregion

		}

		/// <summary>
		/// 
		/// </summary>
		public class reverse_iterator : IEnumerator {
			/// <summary>
			/// 
			/// </summary>
			public reverse_iterator() {}

			/// <summary>
			/// 
			/// </summary>
			/// <param name="e"></param>
			public reverse_iterator(list_element e) { this.e = e; Reset(); }

			/// <summary>
			/// 
			/// </summary>
			/// <param name="it"></param>
			public reverse_iterator(reverse_iterator it) { e = it.e; Reset(); }

			/// <summary>
			/// 
			/// </summary>
			public object value { 
				get { return i.x;} 
				set { i.x = value;}
			}

			/// <summary>
			/// 
			/// </summary>
			/// <param name="it"></param>
			/// <returns></returns>
			public static reverse_iterator operator++(reverse_iterator it) {
				it.inc(); return it;
			}

			/// <summary>
			/// 
			/// </summary>
			/// <param name="it"></param>
			/// <returns></returns>
			public static reverse_iterator operator--(reverse_iterator it) {
				it.dec(); return it;
			}

			/// <summary>
			/// 
			/// </summary>
			/// <param name="a"></param>
			/// <param name="b"></param>
			/// <returns></returns>
			public static bool operator==(reverse_iterator a, reverse_iterator b) {
				return a.i == b.i;
			}

			/// <summary>
			/// 
			/// </summary>
			/// <param name="a"></param>
			/// <param name="b"></param>
			/// <returns></returns>
			public static bool operator!=(reverse_iterator a, reverse_iterator b) {
				return a.i != b.i;
			}

			/// <summary>
			/// 
			/// </summary>
			/// <param name="obj"></param>
			/// <returns></returns>
			public override bool Equals(object obj) {
				reverse_iterator it = obj as reverse_iterator;
				return this.e == it.e && this.i == it.i;
			}

			/// <summary>
			/// 
			/// </summary>
			/// <returns></returns>
			public override int GetHashCode() {
				return e.GetHashCode() ^ i.GetHashCode();
			}

			/// <summary>
			/// 
			/// </summary>
			private void inc() { if (i != null) i = i.prev; }

			/// <summary>
			/// 
			/// </summary>
			private void dec() { if (i != null) i = i.next; }

			/// <summary>
			/// 
			/// </summary>
			private list_element e;

			/// <summary>
			/// 
			/// </summary>
			private list_element i;

			#region IEnumerator �����o

			/// <summary>
			/// 
			/// </summary>
			public void Reset() {
				i = e;
			}

			/// <summary>
			/// 
			/// </summary>
			public object Current {
				get { return i.x;}
			}

			/// <summary>
			/// 
			/// </summary>
			/// <returns></returns>
			public bool MoveNext() {
				if (i.prev == e)
					return false;
				i = i.prev;
				return true;
			}

			#endregion

		}

		/// <summary>
		/// 
		/// </summary>
		public class list_element {
			/// <summary>
			/// 
			/// </summary>
			public list_element prev;

			/// <summary>
			/// 
			/// </summary>
			public list_element next;

			/// <summary>
			/// 
			/// </summary>
			public object x;

			/// <summary>
			/// 
			/// </summary>
			public list_element() {}

			/// <summary>
			/// 
			/// </summary>
			/// <param name="x"></param>
			public list_element(object x) {
				this.x = x;
			}

			/// <summary>
			/// 
			/// </summary>
			/// <param name="x"></param>
			/// <param name="prev"></param>
			/// <param name="next"></param>
			public list_element(object x, list_element prev, list_element next) {
				this.x = x; this.prev = prev; this.next = next;
			}
		}

		/// <summary>
		/// 
		/// </summary>
		protected list_element endnode;

		/// <summary>
		/// 
		/// </summary>
		protected int s;
		#region IEnumerable �����o

		/// <summary>
		/// 
		/// </summary>
		/// <returns></returns>
		public IEnumerator GetEnumerator() {
			return new iterator(endnode);
		}

		#endregion

		/// <summary>
		/// 
		/// </summary>
		public class reverse_list : list, IEnumerable {
			/// <summary>
			/// 
			/// </summary>
			/// <param name="e"></param>
			/// <param name="s"></param>
			public reverse_list(list_element e, int s) : base(e, s) {}
			#region IEnumerable �����o

			/// <summary>
			/// 
			/// </summary>
			/// <returns></returns>
			public new IEnumerator GetEnumerator() {
				return new reverse_iterator(endnode);
			}
			#endregion
		}
	}
}
