using System;
using System.Collections;

namespace y4cs.ytl {
	/// <summary>
	/// vector
	/// </summary>
	public class vector : IEnumerable {
		/// <summary>
		/// 
		/// </summary>
		private object[] a_;
		private int size_;

		/// <summary>
		/// 
		/// </summary>
		public vector() {
			clear();
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="a"></param>
		/// <param name="size"></param>
		public vector(object[] a, int size) {
			a_ = a;
			size_ = size;		
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="n"></param>
		/// <returns></returns>
		public object at(int n) {
			if (n < 0 || n >= a_.Length)
				return null;
			return a_[n];
		}

		/// <summary>
		/// 
		/// </summary>
		/// <returns></returns>
		public int size() {
			return size_;
		}

		/// <summary>
		/// 
		/// </summary>
		/// <returns></returns>
		public int capacity() {
			return a_.Length;
		}

		/// <summary>
		/// 
		/// </summary>
		public object this[int n] {
			get { return a_[n]; }
			set { a_[n] = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="o"></param>
		public void push_back(object o) {
			if (a_.Length == size_) {
				int s = (size_ + 1)*2;
				object[] a = new object[s];
				Array.Copy(a_, a, a_.Length);
				a_ = a;
			}
			a_[size_++] = o;
		}

		/// <summary>
		/// 
		/// </summary>
		public void clear() {
			size_ = 0;
			if (a_ == null) {
				a_ = new object[16];
			}
		}

		/// <summary>
		/// 
		/// </summary>
		/// <returns></returns>
		public bool empty() {
			return size_ == 0;
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="n"></param>
		public void resize(int n) {
			if (n > capacity()) {
				object[] a = a_;
				reserve(n);
				Array.Copy(a, a_, a.Length);
			}
			size_ = n;
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="n"></param>
		public void reserve(int n) {
			if (n > capacity()) {
				int i = n-1; int j = 1;
				while (i != 0) {i>>=1; j<<=1;}
				object[] a = new object[j];
				Array.Copy(a_, a, a_.Length);
				a_ = a;
			}
		}

		/// <summary>
		/// 
		/// </summary>
		/// <returns></returns>
		public object pop_back() {
			if (empty()) 
				return null;
			return a_[--size_];
		}

		/// <summary>
		/// 
		/// </summary>
		/// <returns></returns>
		public object front() {
			if (empty())
				return null;
			return a_[0];
		}

		/// <summary>
		/// 
		/// </summary>
		/// <returns></returns>
		public object back() {
			if (empty())
				return null;
			return a_[size_ - 1];
		}

		/// <summary>
		/// 
		/// </summary>
		/// <returns></returns>
		public iterator begin() {
			return new iterator(a_, size_, 0);
		}

		/// <summary>
		/// 
		/// </summary>
		/// <returns></returns>
		public iterator end() {
			return new iterator(a_, size_, size_);
		}

		/// <summary>
		/// 
		/// </summary>
		/// <returns></returns>
		public IEnumerable reverse() {
			return new reverse_vector(a_, size_);
		}

		/// <summary>
		/// 
		/// </summary>
		/// <returns></returns>
		public reverse_iterator rbegin() {
			return new reverse_iterator(a_, size_);
		}

		/// <summary>
		/// 
		/// </summary>
		/// <returns></returns>
		public reverse_iterator rend() {
			return new reverse_iterator(a_, size_, -1);
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="n"></param>
		public void erase(int n) {
			for (int i = n; i < size() - 1; ++i)
				a_[i] = a_[i + 1];
			a_[--size_] = null;
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="n"></param>
		/// <param name="m"></param>
		public void erase(int n, int m) {
			for (int i = m; i < size(); ++i)
				a_[n+i-m] = a_[m];
			size_ -= m-n;
			for (int i = size(); i < capacity(); ++i)
				a_[i] = null;
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="it"></param>
		/// <returns></returns>
		public iterator erase(iterator it) {
			erase(it.pos);
			return it;
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="bgn"></param>
		/// <param name="end"></param>
		/// <returns></returns>
		public iterator erase(iterator bgn, iterator end) {
			erase(bgn.pos, end.pos);
			return bgn;
		}

		#region IEnumerable �����o

		/// <summary>
		/// 
		/// </summary>
		/// <returns></returns>
		public IEnumerator GetEnumerator() {
			return new iterator(a_, size_);
		}

		#endregion

		/// <summary>
		/// 
		/// </summary>
		public class iterator : IEnumerator, IComparable {

			/// <summary>
			/// 
			/// </summary>
			public iterator() {}

			/// <summary>
			/// 
			/// </summary>
			/// <param name="a"></param>
			/// <param name="size"></param>
			public iterator(object[] a, int size) {
				a_ = a; size_ = size; pos_ = -1; 
			}

			/// <summary>
			/// 
			/// </summary>
			/// <param name="a"></param>
			/// <param name="size"></param>
			/// <param name="pos"></param>
			public iterator(object[] a, int size, int pos) {
				a_ = a; size_ = size; pos_ = pos;
			}

			/// <summary>
			/// 
			/// </summary>
			/// <param name="it"></param>
			public iterator(iterator it) {
				a_ = it.a_; pos_ = it.pos_;
			}

			/// <summary>
			/// 
			/// </summary>
			public object value {
				get { return a_[pos_]; }
				set { a_[pos_] = value; }
			}

			/// <summary>
			/// 
			/// </summary>
			public int pos {
				get { return pos_; }
				set { pos_ = value; }
			}

			/// <summary>
			/// 
			/// </summary>
			/// <param name="it"></param>
			/// <returns></returns>
			public static iterator operator++(iterator it) {
				it.inc(); return it;	
			}

			/// <summary>
			/// 
			/// </summary>
			/// <param name="it"></param>
			/// <returns></returns>
			public static iterator operator--(iterator it) {
				it.dec(); return it;
			}

			/// <summary>
			/// 
			/// </summary>
			/// <param name="it"></param>
			/// <param name="n"></param>
			/// <returns></returns>
			public static iterator operator+(iterator it, int n) {
				iterator i = new iterator(it); i.inc(n); return i;
			}

			/// <summary>
			/// 
			/// </summary>
			/// <param name="it"></param>
			/// <param name="n"></param>
			/// <returns></returns>
			public static iterator operator-(iterator it, int n) {
				iterator i = new iterator(it); i.dec(n); return i;
			}

			/// <summary>
			/// 
			/// </summary>
			/// <param name="a"></param>
			/// <param name="b"></param>
			/// <returns></returns>
			public static bool operator==(iterator a, iterator b) {
				return a.a_ == b.a_ && a.pos_ == b.pos_;
			}

			/// <summary>
			/// 
			/// </summary>
			/// <param name="a"></param>
			/// <param name="b"></param>
			/// <returns></returns>
			public static bool operator!=(iterator a, iterator b) {
				return a.a_ != b.a_ || a.pos_ != b.pos_;
			}

			/// <summary>
			/// 
			/// </summary>
			/// <param name="obj"></param>
			/// <returns></returns>
			public override bool Equals(object obj) {
				iterator it = obj as iterator;
				return this == it;
			}

			/// <summary>
			/// 
			/// </summary>
			/// <returns></returns>
			public override int GetHashCode() {
				return a_.GetHashCode() ^ pos_.GetHashCode();
			}

			/// <summary>
			/// 
			/// </summary>
			private void inc() { inc(1); }

			/// <summary>
			/// 
			/// </summary>
			private void dec() { dec(1); }

			/// <summary>
			/// 
			/// </summary>
			/// <param name="n"></param>
			private void inc(int n) { pos_+=n; if (pos_>size_) pos_=size_; }

			/// <summary>
			/// 
			/// </summary>
			/// <param name="n"></param>
			private void dec(int n) { pos_-=n; if (pos_<0) pos_=0; }

			/// <summary>
			/// 
			/// </summary>
			private int pos_;

			/// <summary>
			/// 
			/// </summary>
			private int size_;

			/// <summary>
			/// 
			/// </summary>
			private object[] a_;

			#region IEnumerator �����o

			/// <summary>
			/// 
			/// </summary>
			public void Reset() {
				pos_ = -1;
			}

			/// <summary>
			/// 
			/// </summary>
			public object Current {
				get {
					return a_[pos_];
				}
			}

			/// <summary>
			/// 
			/// </summary>
			/// <returns></returns>
			public bool MoveNext() {
				if (++pos_ >= size_)
					return false;
				return true;
			}

			#endregion

			#region IComparable �����o

			/// <summary>
			/// 
			/// </summary>
			/// <param name="obj"></param>
			/// <returns></returns>
			public int CompareTo(object obj) {
				iterator it = obj as iterator;
				if (it == null || a_ != it.a_) 
					return 1;
				return pos_ - it.pos_;
			}

			#endregion
		}

		/// <summary>
		/// 
		/// </summary>
		public class reverse_iterator : IEnumerator, IComparable {
			/// <summary>
			/// 
			/// </summary>
			public reverse_iterator() {}

			/// <summary>
			/// 
			/// </summary>
			/// <param name="a"></param>
			/// <param name="size"></param>
			public reverse_iterator(object[] a, int size) {
				a_ = a; size_ = size; pos_ = size - 1;
			}

			/// <summary>
			/// 
			/// </summary>
			/// <param name="a"></param>
			/// <param name="size"></param>
			/// <param name="pos"></param>
			public reverse_iterator(object[] a, int size, int pos) {
				a_ = a; size_ = size; pos_ = pos;
			}

			/// <summary>
			/// 
			/// </summary>
			/// <param name="it"></param>
			public reverse_iterator(reverse_iterator it) {
				a_ = it.a_; pos_ = it.pos_;
			}

			/// <summary>
			/// 
			/// </summary>
			public object value {
				get { return a_[pos_]; }
				set { a_[pos_] = value; }
			}

			/// <summary>
			/// 
			/// </summary>
			public int pos {
				get { return pos_; }
				set { pos_ = value; }
			}

			/// <summary>
			/// 
			/// </summary>
			/// <param name="it"></param>
			/// <returns></returns>
			public static reverse_iterator operator++(reverse_iterator it) {
				it.inc(); return it;	
			}

			/// <summary>
			/// 
			/// </summary>
			/// <param name="it"></param>
			/// <returns></returns>
			public static reverse_iterator operator--(reverse_iterator it) {
				it.dec(); return it;
			}

			/// <summary>
			/// 
			/// </summary>
			/// <param name="it"></param>
			/// <param name="n"></param>
			/// <returns></returns>
			public static reverse_iterator operator+(reverse_iterator it, int n) {
				reverse_iterator i = new reverse_iterator(it); i.inc(n); return i;
			}

			/// <summary>
			/// 
			/// </summary>
			/// <param name="it"></param>
			/// <param name="n"></param>
			/// <returns></returns>
			public static reverse_iterator operator-(reverse_iterator it, int n) {
				reverse_iterator i = new reverse_iterator(it); i.dec(n); return i;
			}

			/// <summary>
			/// 
			/// </summary>
			/// <param name="a"></param>
			/// <param name="b"></param>
			/// <returns></returns>
			public static bool operator==(reverse_iterator a, reverse_iterator b) {
				return a.pos_ == b.pos_;
			}

			/// <summary>
			/// 
			/// </summary>
			/// <param name="a"></param>
			/// <param name="b"></param>
			/// <returns></returns>
			public static bool operator!=(reverse_iterator a, reverse_iterator b) {
				return a.pos_ != b.pos_;
			}

			/// <summary>
			/// 
			/// </summary>
			/// <param name="obj"></param>
			/// <returns></returns>
			public override bool Equals(object obj) {
				reverse_iterator it = obj as reverse_iterator;
				return pos_ == it.pos_;
			}

			/// <summary>
			/// 
			/// </summary>
			/// <returns></returns>
			public override int GetHashCode() {
				return a_.GetHashCode() ^ pos_.GetHashCode();
			}

			/// <summary>
			/// 
			/// </summary>
			private void inc() { inc(1); }

			/// <summary>
			/// 
			/// </summary>
			private void dec() { dec(1); }

			/// <summary>
			/// 
			/// </summary>
			/// <param name="n"></param>
			private void inc(int n) { pos_-=n; if (pos_< -1) pos_=-1; }

			/// <summary>
			/// 
			/// </summary>
			/// <param name="n"></param>
			private void dec(int n) { pos_+=n; if (pos_>= size_) pos_=size_ - 1; }

			/// <summary>
			/// 
			/// </summary>
			private int pos_;

			/// <summary>
			/// 
			/// </summary>
			private int size_;

			/// <summary>
			/// 
			/// </summary>
			private object[] a_;

			#region IEnumerator �����o

			/// <summary>
			/// 
			/// </summary>
			public void Reset() {
				pos_ = size_;
			}

			/// <summary>
			/// 
			/// </summary>
			public object Current {
				get {
					return a_[pos_];
				}
			}

			/// <summary>
			/// 
			/// </summary>
			/// <returns></returns>
			public bool MoveNext() {
				if (--pos_ < 0)
					return false;
				return true;
			}

			#endregion

			#region IComparable �����o

			/// <summary>
			/// 
			/// </summary>
			/// <param name="obj"></param>
			/// <returns></returns>
			public int CompareTo(object obj) {
				reverse_iterator it = obj as reverse_iterator;
				return it.pos_ - pos_;
			}
			#endregion
		}

		/// <summary>
		/// rvector
		/// </summary>
		/// foreach�ŋt�񂵂��邽�߂̃N���X
		/// <example>
		/// ��
		/// <code>
		/// foreach(int n in vec.reverse()) {
		///		Console.WriteLine(n);
		/// }
		/// </code>
		/// </example>
		class reverse_vector : vector, IEnumerable {
			/// <summary>
			/// 
			/// </summary>
			/// <param name="a"></param>
			/// <param name="pos"></param>
			internal reverse_vector(object[] a, int pos) : base(a, pos) {}
			#region IEnumerable �����o

			/// <summary>
			/// 
			/// </summary>
			/// <returns></returns>
			public new IEnumerator GetEnumerator() {
				return new reverse_iterator(a_, size_);
			}

			#endregion
		}
	}
}
