using System;

namespace y4cs.draw {
	///	�]������bltter
	/**
	 <para>
		�]������bltter�ByaneSDK2nd��CPlaneTransBlt���ۂ��́B
		�m�x���Q�[���Ƃ��ŃV�[���؂�ւ��Ɏg���B
	</para>
	<para>
		���̃��W���[���͑傫���̂ŁAimport y4d;�ł͓ǂݍ��܂Ȃ��̂�
		���̃t�@�C������import���Ă��������F
	</para>
	<para>
			private import y4d_draw.transblitter;
	</para>
	<para>
		phase = 0 �` 255�B255�œ]������������̂Ƃ���B
		������Ԃ͎����Ă��Ȃ��B
	</para>

	*/
	public class TransBltter {

		///	������J�[�e���B16 dot�B
		public static void bltSlitCurtain1(Screen dst,ITextureBase src,int x,int y,int phase) {
			bltTransHelper1(dst,src,x,y,phase,true,16); }

		///	�E����J�[�e���B16 dot�B
		public static void bltSlitCurtain2(Screen dst,ITextureBase src,int x,int y,int phase) {
			bltTransHelper1(dst,src,x,y,phase,false,16); }

		///	������J�[�e���B8 dot�B
		public static void bltSlitCurtain3(Screen dst,ITextureBase src,int x,int y,int phase) {
			bltTransHelper1(dst,src,x,y,phase,true,8); }

		///	�E����J�[�e���B8 dot�B
		public static void bltSlitCurtain4(Screen dst,ITextureBase src,int x,int y,int phase) {
			bltTransHelper1(dst,src,x,y,phase,false,8); }

		///	�ォ��̃J�[�e���B16 dot�B
		public static void bltSlitCurtain5(Screen dst,ITextureBase src,int x,int y,int phase) {
			bltTransHelper2(dst,src,x,y,phase,true,16); }

		///	������̃J�[�e���B16 dot�B
		public static void bltSlitCurtain6(Screen dst,ITextureBase src,int x,int y,int phase) {
			bltTransHelper2(dst,src,x,y,phase,false,16); }

		///	�ォ��̃J�[�e���B8 dot�B
		public static void bltSlitCurtain7(Screen dst,ITextureBase src,int x,int y,int phase) {
			bltTransHelper2(dst,src,x,y,phase,true,8); }

		///	������̃J�[�e���B8 dot�B
		public static void bltSlitCurtain8(Screen dst,ITextureBase src,int x,int y,int phase) {
			bltTransHelper2(dst,src,x,y,phase,false,8); }

		///	�ォ��̉~
		public static void bltCircle1(Screen dst,ITextureBase src,int x,int y,int phase) {
			if (dst == null || src == null) return ;
			int sx = (int)src.getWidth(); int sy = (int)src.getHeight();

			int sm;	// max size
			sm = (int)(Math.Sqrt(sx*sx/4+sy*sy)*2);
			int sr;	// rest size
			sr = (sm * phase) >> 8;
			int ssy,py;
			ssy = 0;
			for(py=0;py<(sr>>1);py++,ssy++){
				int px,rx;
				rx = (int)(Math.Sqrt(sr*sr/4-ssy*ssy)*2);
				px = (sx>>1)-(rx>>1);

				//		bltRect(px,py,rx,1); // �N���b�v�t��HLINE
				//	�蓮�}�N��

				//	bltRect(x_,y_,sx_,sy_)
				int x_ = px , y_ = py , sx_=rx , sy_ = 1; {

															  //	�}�N�����Ǝv���˂�
															  Rect rc = new Rect();
															  int	sx2,sy2;
															  sx2= sx_; sy2= sy_;
															  int x2,y2;
															  x2 = x_; y2= y_;
															  if(x2<0) { x2=0; }
															  if(y2<0) { y2=0; }
															  if(x2+sx2 > sx) { sx2 = sx-x2; }
															  if(y2+sy2 > sy) { sy2 = sy-y2; }
															  rc.setRect(x2,y2,x2+sx2,y2+sy2);
															  dst.blt(src,x+x2,y+y2,ref rc);
														  }
			}
		}

		///	������̉~
		public static void bltCircle2(Screen dst,ITextureBase src,int x,int y,int phase) {
			if (dst == null || src == null) return ;
			int sx = (int)src.getWidth(); int sy = (int)src.getHeight();

			int sm;	// max size
			sm = (int)(Math.Sqrt(sx*sx/4+sy*sy)*2);
			int sr;	// rest size
			sr = (sm * phase) >> 8;
			int ssy,py;
			ssy = 0;
			for(py=sy;py>sy-(sr>>1);py--,ssy++){
				int px,rx;
				rx = (int)(Math.Sqrt(sr*sr/4-ssy*ssy)*2);
				px = (sx>>1)-(rx>>1);

				//		bltRect(px,py,rx,1); // �N���b�v�t��HLINE
				//	�蓮�}�N��

				//	bltRect(x_,y_,sx_,sy_)
				int x_ = px , y_ = py , sx_=rx , sy_ = 1; {

															  //	�}�N�����Ǝv���˂�
															  Rect rc = new Rect();
															  int	sx2,sy2;
															  sx2= sx_; sy2= sy_;
															  int x2,y2;
															  x2 = x_; y2= y_;
															  if(x2<0) { x2=0; }
															  if(y2<0) { y2=0; }
															  if(x2+sx2 > sx) { sx2 = sx-x2; }
															  if(y2+sy2 > sy) { sy2 = sy-y2; }
															  rc.setRect(x2,y2,x2+sx2,y2+sy2);
															  dst.blt(src,x+x2,y+y2,ref rc);
														  }
			}
		}

		///	������̉~
		public static void bltCircle3(Screen dst,ITextureBase src,int x,int y,int phase) {
			if (dst == null || src == null) return ;
			int sx = (int)src.getWidth(); int sy = (int)src.getHeight();

			int sm;	// max size
			sm = (int)(Math.Sqrt(sx*sx+sy*sy/4)*2);
			int sr;	// rest size
			sr = (sm * phase) >> 8;
			int ssy = 0,py = 0;
			ssy =-(sr >> 1);
			for(py=(sy>>1)-(sr>>1);py<((sy>>1)+(sr>>1));py++,ssy++){
				int px,rx;
				rx = (int)(Math.Sqrt(sr*sr/4-ssy*ssy));
				px = 0;

				//		bltRect(px,py,rx,1); // �N���b�v�t��HLINE
				//	�蓮�}�N��

				//	bltRect(x_,y_,sx_,sy_)
				int x_ = px , y_ = py , sx_=rx , sy_ = 1; {

															  //	�}�N�����Ǝv���˂�
															  Rect rc = new Rect();
															  int	sx2,sy2;
															  sx2= sx_; sy2= sy_;
															  int x2,y2;
															  x2 = x_; y2= y_;
															  if(x2<0) { x2=0; }
															  if(y2<0) { y2=0; }
															  if(x2+sx2 > sx) { sx2 = sx-x2; }
															  if(y2+sy2 > sy) { sy2 = sy-y2; }
															  rc.setRect(x2,y2,x2+sx2,y2+sy2);
															  dst.blt(src,x+x2,y+y2,ref rc);
														  }
			}
		}

		///	�E����̉~
		public static void bltCircle4(Screen dst,ITextureBase src,int x,int y,int phase) {
			if (dst == null || src == null) return ;
			int sx = (int)src.getWidth(); int sy = (int)src.getHeight();

			int sm;	// max size
			sm = (int)(Math.Sqrt(sx*sx+sy*sy/4)*2);
			int sr;	// rest size
			sr = (sm * phase) >> 8;
			int ssy,py;
			ssy =-(sr >> 1);
			for(py=(sy>>1)-(sr>>1);py<((sy>>1)+(sr>>1));py++,ssy++){
				int px,rx;
				rx = (int)(Math.Sqrt(sr*sr/4-ssy*ssy));
				px = sx-rx;

				//		bltRect(px,py,rx,1); // �N���b�v�t��HLINE
				//	�蓮�}�N��

				//	bltRect(x_,y_,sx_,sy_)
				int x_ = px , y_ = py , sx_=rx , sy_ = 1; {

															  //	�}�N�����Ǝv���˂�
															  Rect rc = new Rect();
															  int	sx2,sy2;
															  sx2= sx_; sy2= sy_;
															  int x2,y2;
															  x2 = x_; y2= y_;
															  if(x2<0) { x2=0; }
															  if(y2<0) { y2=0; }
															  if(x2+sx2 > sx) { sx2 = sx-x2; }
															  if(y2+sy2 > sy) { sy2 = sy-y2; }
															  rc.setRect(x2,y2,x2+sx2,y2+sy2);
															  dst.blt(src,x+x2,y+y2, ref rc);
														  }
			}
		}

		///	��������̉~
		public static void bltCircle5(Screen dst,ITextureBase src,int x,int y,int phase) {
			if (dst == null || src == null) return ;
			int sx = (int)src.getWidth(); int sy = (int)src.getHeight();

			int sm;	// max size
			sm = sx+sy;
			int sr;	// rest size
			sr = (sm * phase) >> 8;
			int ssy,py;
			ssy =-(sr >> 1);
			for(py=(sy>>1)-(sr>>1);py<((sy>>1)+(sr>>1));py++,ssy++){
				int px,rx;
				rx = (int)(Math.Sqrt(sr*sr/4-ssy*ssy)*2); // bug-fixed '00/02/24
				px = (sx>>1)-(rx>>1);

				//		bltRect(px,py,rx,1); // �N���b�v�t��HLINE
				//	�蓮�}�N��

				//	bltRect(x_,y_,sx_,sy_)
				int x_ = px , y_ = py , sx_=rx , sy_ = 1; {

															  //	�}�N�����Ǝv���˂�
															  Rect rc = new Rect();
															  int	sx2,sy2;
															  sx2= sx_; sy2= sy_;
															  int x2,y2;
															  x2 = x_; y2= y_;
															  if(x2<0) { x2=0; }
															  if(y2<0) { y2=0; }
															  if(x2+sx2 > sx) { sx2 = sx-x2; }
															  if(y2+sy2 > sy) { sy2 = sy-y2; }
															  rc.setRect(x2,y2,x2+sx2,y2+sy2);
															  dst.blt(src,x+x2,y+y2,ref rc);
														  }
			}
		}

		///	�����܂� �O���� 2*2
		public static void bltWhorl1(Screen dst,ITextureBase src,int x,int y,int phase) {
			int[] uzu = {
								  0, 1, 2, 3,
								  11,12,13, 4,
								  10,15,14, 5,
								  9, 8, 7, 6
							  };
			bltTransHelper3(dst,src,x,y,phase,2,uzu);
		}


		///	�����܂� ������ 2*2
		public static void bltWhorl2(Screen dst,ITextureBase src,int x,int y,int phase) {
			int [] uzu = {
									6, 7, 8, 9,
									5, 0, 1,10,
									4, 3, 2,11,
									15,14,13,12
								};
			bltTransHelper3(dst,src,x,y,phase,2,uzu);
		}

		///	�����܂� �O���� 4*4
		public static void bltWhorl3(Screen dst,ITextureBase src,int x,int y,int phase) {
			int[] uzu = {
								  0, 1, 2, 3,
								  11,12,13, 4,
								  10,15,14, 5,
								  9, 8, 7, 6
							  };
			bltTransHelper3(dst,src,x,y,phase,4,uzu);
		}

		///	�����܂� ������ 4*4
		public static void bltWhorl4(Screen dst,ITextureBase src,int x,int y,int phase) {
			int[] uzu = {
								  6, 7, 8, 9,
								  5, 0, 1,10,
								  4, 3, 2,11,
								  15,14,13,12
							  };
			bltTransHelper3(dst,src,x,y,phase,4,uzu);
		}

		///	�����܂� �O���� 8*8
		public static void bltWhorl5(Screen dst,ITextureBase src,int x,int y,int phase) {
			int[] uzu = {
								  0, 1, 2, 3,
								  11,12,13, 4,
								  10,15,14, 5,
								  9, 8, 7, 6
							  };
			bltTransHelper3(dst,src,x,y,phase,8,uzu);
		}

		///	�����܂� ������ 8*8
		public static void bltWhorl6(Screen dst,ITextureBase src,int x,int y,int phase) {
			int[] uzu = {
								  6, 7, 8, 9,
								  5, 0, 1,10,
								  4, 3, 2,11,
								  15,14,13,12
							  };
			bltTransHelper3(dst,src,x,y,phase,8,uzu);
		}

		// --------------- �ȉ���helper -------------------------------------------

		/// ���E����̃J�[�e���B
		/**
			SlitCurtainBlt����Ăяo�����w���p�֐��B
			bLeft == true�Ȃ�΍�����Bfalse�Ȃ�E����̃J�[�e���B
		*/
		public static void bltTransHelper1(Screen dst,ITextureBase src,int x,int y,int phase,bool bLeft,int width){
			if (dst == null || src == null) return ;
			int sx = (int)src.getWidth(); int sy = (int)src.getHeight();

			int ColumnNum = (sx + width + 1) / width;
			int c = (phase * (ColumnNum + width)) / 256;
			int i, j;
			Rect rc = new Rect();

			rc.top = 0;
			rc.bottom = sy;
			for(i = 0; i < ColumnNum && i < c; ++i){
				j = c - i;
				if(j > width)
					j = width;
				rc.left = i * width;
				if(bLeft){
					rc.right = rc.left + j;
				}else{
					rc.right = sx - rc.left;
					rc.left = rc.right - j;
				}
				if(rc.right > sx)
					rc.right = sx - 1;
				if(rc.left < 0)
					rc.left = 0;

				dst.blt(src,(int)(x + rc.left), y, ref rc);
			}
		}

		/// �㉺�̃J�[�e���B
		/**
			SlitCurtainBlt����Ăяo�����w���p�֐��B
			bTop == true�Ȃ�Ώォ��Bfalse�Ȃ牺����̃J�[�e���B
		*/
		public static void bltTransHelper2(Screen dst,ITextureBase src,int x,int y,int phase,bool bTop,int height){

			if (dst == null || src == null) return ;
			int sx = (int)src.getWidth(); int sy = (int)src.getHeight();

			int ColumnNum = (sy + height + 1) / height;
			int c = (phase * (ColumnNum + height)) / 256;
			int i, j;
			Rect rc;

			rc.left = 0;
			rc.right = sx;
			for(i = 0; i < ColumnNum && i < c; ++i){
				j = c - i;
				if(j > height)
					j = height;
				rc.top = i * height;
				if(bTop){
					rc.bottom = rc.top + j;
				}else{
					rc.bottom = sy - rc.top;
					rc.top = rc.bottom - j;
				}
				if(rc.bottom > sy)
					rc.bottom = sy - 1;
				if(rc.top < 0)
					rc.top = 0;

				dst.blt(src,x, (int)(y + rc.top),ref rc);
			}
		}

		///	�����܂�etc..
		/**
			uzu��4*4�̔z��B�g��������bltWhorl1���Q�l�ɂ��邱�ƁB
		*/
		public static void bltTransHelper3(Screen dst,ITextureBase src,int x,int y,int phase,int a,int[] uzu){
			if (dst == null || src == null) return ;
			int sx = (int)src.getWidth(); int sy = (int)src.getHeight();

			phase >>= 4;
			for(int py=0,py2=0;py<sy;py+=a,++py2){
				for(int px=0,px2=0;px<sx;px+=a,++px2){
					if (uzu[(px2 & 3)+((py2 & 3)<<2) & 15] <= phase){

						//		bltRect(px,py,a,a); // �N���b�v�t��HLINE
						//	�蓮�}�N��

						//	bltRect(x_,y_,sx_,sy_)
						int x_ = px , y_ = py , sx_=a , sy_ = a; {

																	 //	�}�N�����Ǝv���˂�
																	 Rect rc = new Rect();
																	 int	sx2,sy2;
																	 sx2= sx_; sy2= sy_;
																	 int x2,y2;
																	 x2 = x_; y2= y_;
																	 if(x2<0) { x2=0; }
																	 if(y2<0) { y2=0; }
																	 if(x2+sx2 > sx) { sx2 = sx-x2; }
																	 if(y2+sy2 > sy) { sy2 = sy-y2; }
																	 rc.setRect(x2,y2,x2+sx2,y2+sy2);
																	 dst.blt(src,x+x2,y+y2,ref rc);
																 }

					}
				}
			}
		}
	}
}

