using System;
using System.Runtime.InteropServices;
using y4cs.sdl;

namespace y4cs.input
{
	/// <summary>
	/// �L�[���̓N���X�B
	/// </summary>
	/// <remarks>
	/// <para>
	/// �L�[�̃X�L�����R�[�h��SDL�̂��̂Ɠ���
	/// ��SDL/SDL_keysym.d���Q�Ƃ̂��ƁB
	/// ��SDL��import���������Ȃ��ꍇ�A
	/// 	���̃w�b�_�̂Ȃ��ɂ���KeyCode�Ƃ���enum��p���Ă��ǂ��B
	/// </para>
	/// <para>
	/// �֐��d�l�ɂ��Ă�JoyStick�Ɠ����Ȃ̂ł�������Q�Ƃ̂��ƁB
	/// </para>
	/// </remarks>
	public class KeyBoardInput : KeyInputBase {

		/// <summary>
		/// 
		/// </summary>
		/// <param name="nButtonNo"></param>
		/// <returns></returns>
		public bool isPush(int nButtonNo) {
			if (nButtonNo > getButtonNum()) return false;
			return (buttonState[1-flip][nButtonNo]==false)
				&& (buttonState[flip][nButtonNo]!=false);
		}

		public bool isPush() {
			for (int i = 0; i < getButtonNum(); ++i) {
				if (isPush(i))
					return true;
			}
			return false;
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="nButtonNo"></param>
		/// <returns></returns>
		public bool isPress(int nButtonNo) {
			if (nButtonNo > getButtonNum()) return false;
			return (buttonState[flip][nButtonNo]!=false);
		}

		public bool isPress() {
			for (int i = 0; i < getButtonNum(); ++i) {
				if (isPress(i))
					return true;
			}
			return false;
		}


		/// <summary>
		/// 
		/// </summary>
		/// <returns></returns>
		public int getButtonNum() { return buttonState[0].Length; }

		/// <summary>
		/// 
		/// </summary>
		/// <returns></returns>
		public string getDeviceName() { return "KeyBoard"; }

		/// <summary>
		/// 
		/// </summary>
		/// <returns></returns>
		public IntPtr getInfo() { return IntPtr.Zero; }

		/// <summary>
		/// 
		/// </summary>
		/// <remarks>
		/// <para>
		/// SDL��SDL_PumpEvents�����I�ɌĂяo���Ă��邱�Ƃ�O��Ƃ���B
		/// �����œ�����̂͑O���SDL_PumpEvents���Ăяo���Ă����
		/// ���͏��ł���B
		/// </para>
		/// <para>
		/// �܂��A�L�[���͂ɂ́A
		/// 	SDL_SetVideoMode(640,480,16,SDL_SWSURFACE);
		/// �ɑ������閽�߂ŁASDL�̃E�B���h�D�����������Ă���K�v������B
		/// (�L�[���͂́A�E�B���h�D�ɕt�т�����̂Ȃ̂�)	
		/// </para>
		/// </remarks>
		public void update() {
			flip = 1 - flip;

			IntPtr pkeys = SDL.SDL_GetKeyState(IntPtr.Zero);
			byte[] keys = new byte[getButtonNum()];
			Marshal.Copy(pkeys, keys, 0, keys.Length);

			for(int i=0;i<keys.Length;i++){
				buttonState[flip][i] = keys[i]!=0;
			}
		}

		/// <summary>
		/// 
		/// </summary>
		public KeyBoardInput() {
			buttonState = new bool[2][];
			for(int i=0;i<2;++i){
				buttonState[i] = new bool[(int)KeyCode.LAST];
			}
		}

		/// <summary>
		/// �O��̓��͏�Ԃƍ���̓��͏�ԁB
		/// </summary>
		private bool[][]	buttonState;
		/// <summary>
		/// �O��̓��͏�Ԃƍ���̓��͏�Ԃ�flip�����Ďg���Bflip={0,1}
		/// </summary>
		private int flip;
	}

	/// <summary>
	/// KeyBoardInput�ŗp����L�[�X�L�����R�[�h
	/// </summary>
	public enum KeyCode : int {
		/* The keyboard syms have been cleverly chosen to map to ASCII */
		/// <summary>
		/// 
		/// </summary>
		UNKNOWN		= 0,
		/// <summary>
		/// 
		/// </summary>
		FIRST		= 0,
		/// <summary>
		/// 
		/// </summary>
		BACKSPACE		= 8,
		/// <summary>
		/// 
		/// </summary>
		TAB		= 9,
		/// <summary>
		/// 
		/// </summary>
		CLEAR		= 12,
		/// <summary>
		/// 
		/// </summary>
		RETURN		= 13,
		/// <summary>
		/// 
		/// </summary>
		PAUSE		= 19,
		/// <summary>
		/// 
		/// </summary>
		ESCAPE		= 27,
		/// <summary>
		/// 
		/// </summary>
		SPACE		= 32,
		/// <summary>
		/// 
		/// </summary>
		EXCLAIM		= 33,
		/// <summary>
		/// 
		/// </summary>
		QUOTEDBL		= 34,
		/// <summary>
		/// 
		/// </summary>
		HASH		= 35,
		/// <summary>
		/// 
		/// </summary>
		DOLLAR		= 36,
		/// <summary>
		/// 
		/// </summary>
		AMPERSAND		= 38,
		/// <summary>
		/// 
		/// </summary>
		QUOTE		= 39,
		/// <summary>
		/// 
		/// </summary>
		LEFTPAREN		= 40,
		/// <summary>
		/// 
		/// </summary>
		RIGHTPAREN		= 41,
		/// <summary>
		/// 
		/// </summary>
		ASTERISK		= 42,
		/// <summary>
		/// 
		/// </summary>
		PLUS		= 43,
		/// <summary>
		/// 
		/// </summary>
		COMMA		= 44,
		/// <summary>
		/// 
		/// </summary>
		MINUS		= 45,
		/// <summary>
		/// 
		/// </summary>
		PERIOD		= 46,
		/// <summary>
		/// 
		/// </summary>
		SLASH		= 47,
		/// <summary>
		/// 
		/// </summary>
		KEY0			= 48,
		/// <summary>
		/// 
		/// </summary>
		KEY1			= 49,
		/// <summary>
		/// 
		/// </summary>
		KEY2			= 50,
		/// <summary>
		/// 
		/// </summary>
		KEY3			= 51,
		/// <summary>
		/// 
		/// </summary>
		KEY4			= 52,
		/// <summary>
		/// 
		/// </summary>
		KEY5			= 53,
		/// <summary>
		/// 
		/// </summary>
		KEY6			= 54,
		/// <summary>
		/// 
		/// </summary>
		KEY7			= 55,
		/// <summary>
		/// 
		/// </summary>
		KEY8			= 56,
		/// <summary>
		/// 
		/// </summary>
		KEY9			= 57,
		/// <summary>
		/// 
		/// </summary>
		COLON		= 58,
		/// <summary>
		/// 
		/// </summary>
		SEMICOLON		= 59,
		/// <summary>
		/// 
		/// </summary>
		LESS		= 60,
		/// <summary>
		/// 
		/// </summary>
		EQUAL		= 61,
		/// <summary>
		/// 
		/// </summary>
		GREATER		= 62,
		/// <summary>
		/// 
		/// </summary>
		QUESTION		= 63,
		/// <summary>
		/// 
		/// </summary>
		AT			= 64,
		/* 
		   Skip uppercase letters
		 */
		/// <summary>
		/// 
		/// </summary>
		LEFTBRACKET	= 91,
		/// <summary>
		/// 
		/// </summary>
		BACKSLASH		= 92,
		/// <summary>
		/// 
		/// </summary>
		RIGHTBRACKET	= 93,
		/// <summary>
		/// 
		/// </summary>
		CARET		= 94,
		/// <summary>
		/// 
		/// </summary>
		UNDERSCORE		= 95,
		/// <summary>
		/// 
		/// </summary>
		BACKQUOTE		= 96,
		/// <summary>
		/// 
		/// </summary>
		a			= 97,
		/// <summary>
		/// 
		/// </summary>
		b			= 98,
		/// <summary>
		/// 
		/// </summary>
		c			= 99,
		/// <summary>
		/// 
		/// </summary>
		d			= 100,
		/// <summary>
		/// 
		/// </summary>
		e			= 101,
		/// <summary>
		/// 
		/// </summary>
		f			= 102,
		/// <summary>
		/// 
		/// </summary>
		g			= 103,
		/// <summary>
		/// 
		/// </summary>
		h			= 104,
		/// <summary>
		/// 
		/// </summary>
		i			= 105,
		/// <summary>
		/// 
		/// </summary>
		j			= 106,
		/// <summary>
		/// 
		/// </summary>
		k			= 107,
		/// <summary>
		/// 
		/// </summary>
		l			= 108,
		/// <summary>
		/// 
		/// </summary>
		m			= 109,
		/// <summary>
		/// 
		/// </summary>
		n			= 110,
		/// <summary>
		/// 
		/// </summary>
		o			= 111,
		/// <summary>
		/// 
		/// </summary>
		p			= 112,
		/// <summary>
		/// 
		/// </summary>
		q			= 113,
		/// <summary>
		/// 
		/// </summary>
		r			= 114,
		/// <summary>
		/// 
		/// </summary>
		s			= 115,
		/// <summary>
		/// 
		/// </summary>
		t			= 116,
		/// <summary>
		/// 
		/// </summary>
		u			= 117,
		/// <summary>
		/// 
		/// </summary>
		v			= 118,
		/// <summary>
		/// 
		/// </summary>
		w			= 119,
		/// <summary>
		/// 
		/// </summary>
		x			= 120,
		/// <summary>
		/// 
		/// </summary>
		y			= 121,
		/// <summary>
		/// 
		/// </summary>
		z			= 122,
		/// <summary>
		/// 
		/// </summary>
		DELETE		= 127,
		/* End of ASCII mapped keysyms */

		/* International keyboard syms */
		/// <summary>
		/// 
		/// </summary>
		WORLD_0		= 160,		/* 0xA0 */
		/// <summary>
		/// 
		/// </summary>
		WORLD_1		= 161,
		/// <summary>
		/// 
		/// </summary>
		WORLD_2		= 162,
		/// <summary>
		/// 
		/// </summary>
		WORLD_3		= 163,
		/// <summary>
		/// 
		/// </summary>
		WORLD_4		= 164,
		/// <summary>
		/// 
		/// </summary>
		WORLD_5		= 165,
		/// <summary>
		/// 
		/// </summary>
		WORLD_6		= 166,
		/// <summary>
		/// 
		/// </summary>
		WORLD_7		= 167,
		/// <summary>
		/// 
		/// </summary>
		WORLD_8		= 168,
		/// <summary>
		/// 
		/// </summary>
		WORLD_9		= 169,
		/// <summary>
		/// 
		/// </summary>
		WORLD_10		= 170,
		/// <summary>
		/// 
		/// </summary>
		WORLD_11		= 171,
		/// <summary>
		/// 
		/// </summary>
		WORLD_12		= 172,
		/// <summary>
		/// 
		/// </summary>
		WORLD_13		= 173,
		/// <summary>
		/// 
		/// </summary>
		WORLD_14		= 174,
		/// <summary>
		/// 
		/// </summary>
		WORLD_15		= 175,
		/// <summary>
		/// 
		/// </summary>
		WORLD_16		= 176,
		/// <summary>
		/// 
		/// </summary>
		WORLD_17		= 177,
		/// <summary>
		/// 
		/// </summary>
		WORLD_18		= 178,
		/// <summary>
		/// 
		/// </summary>
		WORLD_19		= 179,
		/// <summary>
		/// 
		/// </summary>
		WORLD_20		= 180,
		/// <summary>
		/// 
		/// </summary>
		WORLD_21		= 181,
		/// <summary>
		/// 
		/// </summary>
		WORLD_22		= 182,
		/// <summary>
		/// 
		/// </summary>
		WORLD_23		= 183,
		/// <summary>
		/// 
		/// </summary>
		WORLD_24		= 184,
		/// <summary>
		/// 
		/// </summary>
		WORLD_25		= 185,
		/// <summary>
		/// 
		/// </summary>
		WORLD_26		= 186,
		/// <summary>
		/// 
		/// </summary>
		WORLD_27		= 187,
		/// <summary>
		/// 
		/// </summary>
		WORLD_28		= 188,
		/// <summary>
		/// 
		/// </summary>
		WORLD_29		= 189,
		/// <summary>
		/// 
		/// </summary>
		WORLD_30		= 190,
		/// <summary>
		/// 
		/// </summary>
		WORLD_31		= 191,
		/// <summary>
		/// 
		/// </summary>
		WORLD_32		= 192,
		/// <summary>
		/// 
		/// </summary>
		WORLD_33		= 193,
		/// <summary>
		/// 
		/// </summary>
		WORLD_34		= 194,
		/// <summary>
		/// 
		/// </summary>
		WORLD_35		= 195,
		/// <summary>
		/// 
		/// </summary>
		WORLD_36		= 196,
		/// <summary>
		/// 
		/// </summary>
		WORLD_37		= 197,
		/// <summary>
		/// 
		/// </summary>
		WORLD_38		= 198,
		/// <summary>
		/// 
		/// </summary>
		WORLD_39		= 199,
		/// <summary>
		/// 
		/// </summary>
		WORLD_40		= 200,
		/// <summary>
		/// 
		/// </summary>
		WORLD_41		= 201,
		/// <summary>
		/// 
		/// </summary>
		WORLD_42		= 202,
		/// <summary>
		/// 
		/// </summary>
		WORLD_43		= 203,
		/// <summary>
		/// 
		/// </summary>
		WORLD_44		= 204,
		/// <summary>
		/// 
		/// </summary>
		WORLD_45		= 205,
		/// <summary>
		/// 
		/// </summary>
		WORLD_46		= 206,
		/// <summary>
		/// 
		/// </summary>
		WORLD_47		= 207,
		/// <summary>
		/// 
		/// </summary>
		WORLD_48		= 208,
		/// <summary>
		/// 
		/// </summary>
		WORLD_49		= 209,
		/// <summary>
		/// 
		/// </summary>
		WORLD_50		= 210,
		/// <summary>
		/// 
		/// </summary>
		WORLD_51		= 211,
		/// <summary>
		/// 
		/// </summary>
		WORLD_52		= 212,
		/// <summary>
		/// 
		/// </summary>
		WORLD_53		= 213,
		/// <summary>
		/// 
		/// </summary>
		WORLD_54		= 214,
		/// <summary>
		/// 
		/// </summary>
		WORLD_55		= 215,
		/// <summary>
		/// 
		/// </summary>
		WORLD_56		= 216,
		/// <summary>
		/// 
		/// </summary>
		WORLD_57		= 217,
		/// <summary>
		/// 
		/// </summary>
		WORLD_58		= 218,
		/// <summary>
		/// 
		/// </summary>
		WORLD_59		= 219,
		/// <summary>
		/// 
		/// </summary>
		WORLD_60		= 220,
		/// <summary>
		/// 
		/// </summary>
		WORLD_61		= 221,
		/// <summary>
		/// 
		/// </summary>
		WORLD_62		= 222,
		/// <summary>
		/// 
		/// </summary>
		WORLD_63		= 223,
		/// <summary>
		/// 
		/// </summary>
		WORLD_64		= 224,
		/// <summary>
		/// 
		/// </summary>
		WORLD_65		= 225,
		/// <summary>
		/// 
		/// </summary>
		WORLD_66		= 226,
		/// <summary>
		/// 
		/// </summary>
		WORLD_67		= 227,
		/// <summary>
		/// 
		/// </summary>
		WORLD_68		= 228,
		/// <summary>
		/// 
		/// </summary>
		WORLD_69		= 229,
		/// <summary>
		/// 
		/// </summary>
		WORLD_70		= 230,
		/// <summary>
		/// 
		/// </summary>
		WORLD_71		= 231,
		/// <summary>
		/// 
		/// </summary>
		WORLD_72		= 232,
		/// <summary>
		/// 
		/// </summary>
		WORLD_73		= 233,
		/// <summary>
		/// 
		/// </summary>
		WORLD_74		= 234,
		/// <summary>
		/// 
		/// </summary>
		WORLD_75		= 235,
		/// <summary>
		/// 
		/// </summary>
		WORLD_76		= 236,
		/// <summary>
		/// 
		/// </summary>
		WORLD_77		= 237,
		/// <summary>
		/// 
		/// </summary>
		WORLD_78		= 238,
		/// <summary>
		/// 
		/// </summary>
		WORLD_79		= 239,
		/// <summary>
		/// 
		/// </summary>
		WORLD_80		= 240,
		/// <summary>
		/// 
		/// </summary>
		WORLD_81		= 241,
		/// <summary>
		/// 
		/// </summary>
		WORLD_82		= 242,
		/// <summary>
		/// 
		/// </summary>
		WORLD_83		= 243,
		/// <summary>
		/// 
		/// </summary>
		WORLD_84		= 244,
		/// <summary>
		/// 
		/// </summary>
		WORLD_85		= 245,
		/// <summary>
		/// 
		/// </summary>
		WORLD_86		= 246,
		/// <summary>
		/// 
		/// </summary>
		WORLD_87		= 247,
		/// <summary>
		/// 
		/// </summary>
		WORLD_88		= 248,
		/// <summary>
		/// 
		/// </summary>
		WORLD_89		= 249,
		/// <summary>
		/// 
		/// </summary>
		WORLD_90		= 250,
		/// <summary>
		/// 
		/// </summary>
		WORLD_91		= 251,
		/// <summary>
		/// 
		/// </summary>
		WORLD_92		= 252,
		/// <summary>
		/// 
		/// </summary>
		WORLD_93		= 253,
		/// <summary>
		/// 
		/// </summary>
		WORLD_94		= 254,
		/// <summary>
		/// 
		/// </summary>
		WORLD_95		= 255,		/* 0xFF */

		/* Numeric keypad */
		/// <summary>
		/// 
		/// </summary>
		KP0		= 256,
		/// <summary>
		/// 
		/// </summary>
		KP1		= 257,
		/// <summary>
		/// 
		/// </summary>
		KP2		= 258,
		/// <summary>
		/// 
		/// </summary>
		KP3		= 259,
		/// <summary>
		/// 
		/// </summary>
		KP4		= 260,
		/// <summary>
		/// 
		/// </summary>
		KP5		= 261,
		/// <summary>
		/// 
		/// </summary>
		KP6		= 262,
		/// <summary>
		/// 
		/// </summary>
		KP7		= 263,
		/// <summary>
		/// 
		/// </summary>
		KP8		= 264,
		/// <summary>
		/// 
		/// </summary>
		KP9		= 265,
		/// <summary>
		/// 
		/// </summary>
		KP_PERIOD		= 266,
		/// <summary>
		/// 
		/// </summary>
		KP_DIVIDE		= 267,
		/// <summary>
		/// 
		/// </summary>
		KP_MULTIPLY	= 268,
		/// <summary>
		/// 
		/// </summary>
		KP_MINUS		= 269,
		/// <summary>
		/// 
		/// </summary>
		KP_PLUS		= 270,
		/// <summary>
		/// 
		/// </summary>
		KP_ENTER		= 271,
		/// <summary>
		/// 
		/// </summary>
		KP_EQUALS		= 272,

		/* Arrows + Home/End pad */
		/// <summary>
		/// 
		/// </summary>
		UP			= 273,
		/// <summary>
		/// 
		/// </summary>
		DOWN		= 274,
		/// <summary>
		/// 
		/// </summary>
		RIGHT		= 275,
		/// <summary>
		/// 
		/// </summary>
		LEFT		= 276,
		/// <summary>
		/// 
		/// </summary>
		INSERT		= 277,
		/// <summary>
		/// 
		/// </summary>
		HOME		= 278,
		/// <summary>
		/// 
		/// </summary>
		END		= 279,
		/// <summary>
		/// 
		/// </summary>
		PAGEUP		= 280,
		/// <summary>
		/// 
		/// </summary>
		PAGEDOWN		= 281,

		/* Function keys */
		/// <summary>
		/// 
		/// </summary>
		F1			= 282,
		/// <summary>
		/// 
		/// </summary>
		F2			= 283,
		/// <summary>
		/// 
		/// </summary>
		F3			= 284,
		/// <summary>
		/// 
		/// </summary>
		F4			= 285,
		/// <summary>
		/// 
		/// </summary>
		F5			= 286,
		/// <summary>
		/// 
		/// </summary>
		F6			= 287,
		/// <summary>
		/// 
		/// </summary>
		F7			= 288,
		/// <summary>
		/// 
		/// </summary>
		F8			= 289,
		/// <summary>
		/// 
		/// </summary>
		F9			= 290,
		/// <summary>
		/// 
		/// </summary>
		F10		= 291,
		/// <summary>
		/// 
		/// </summary>
		F11		= 292,
		/// <summary>
		/// 
		/// </summary>
		F12		= 293,
		/// <summary>
		/// 
		/// </summary>
		F13		= 294,
		/// <summary>
		/// 
		/// </summary>
		F14		= 295,
		/// <summary>
		/// 
		/// </summary>
		F15		= 296,

		/* Key state modifier keys */
		/// <summary>
		/// 
		/// </summary>
		NUMLOCK		= 300,
		/// <summary>
		/// 
		/// </summary>
		CAPSLOCK		= 301,
		/// <summary>
		/// 
		/// </summary>
		SCROLLOCK		= 302,
		/// <summary>
		/// 
		/// </summary>
		RSHIFT		= 303,
		/// <summary>
		/// 
		/// </summary>
		LSHIFT		= 304,
		/// <summary>
		/// 
		/// </summary>
		RCTRL		= 305,
		/// <summary>
		/// 
		/// </summary>
		LCTRL		= 306,
		/// <summary>
		/// 
		/// </summary>
		RALT		= 307,
		/// <summary>
		/// 
		/// </summary>
		LALT		= 308,
		/// <summary>
		/// 
		/// </summary>
		RMETA		= 309,
		/// <summary>
		/// 
		/// </summary>
		LMETA		= 310,
		/// <summary>
		/// Left "Windows" key
		/// </summary>
		LSUPER		= 311,
		/// <summary>
		/// Right "Windows" key
		/// </summary>
		RSUPER		= 312,
		/// <summary>
		/// "Alt Gr" key
		/// </summary>
		MODE		= 313,
		/// <summary>
		/// Multi-key compose key
		/// </summary>
		COMPOSE		= 314,

		/* Miscellaneous function keys */
		/// <summary>
		/// 
		/// </summary>
		HELP		= 315,
		/// <summary>
		/// 
		/// </summary>
		PRINT		= 316,
		/// <summary>
		/// 
		/// </summary>
		SYSREQ		= 317,
		/// <summary>
		/// 
		/// </summary>
		BREAK		= 318,
		/// <summary>
		/// 
		/// </summary>
		MENU		= 319,
		/// <summary>
		/// Power Macintosh power key
		/// </summary>
		POWER		= 320,
		/// <summary>
		/// Some european keyboards
		/// </summary>
		EURO		= 321,
		/// <summary>
		/// Atari keyboard has Undo
		/// </summary>
		UNDO		= 322,

		/* Add any other keys here */
		/// <summary>
		/// 
		/// </summary>
		LAST
	}
}
