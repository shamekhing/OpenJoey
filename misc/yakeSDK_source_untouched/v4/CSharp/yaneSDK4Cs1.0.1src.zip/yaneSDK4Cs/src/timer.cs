using System;
using y4cs.ytl;
using y4cs.sdl;

namespace y4cs.timer
{
	/// <summary>
	/// 
	/// </summary>
	internal class Timer_ {
		public int getTime() { return (int)SDL.SDL_GetTicks(); }
	}

	/// <summary>
	/// Timer �̊T�v�̐����ł��B
	/// </summary>
	public class Timer
	{
		/// <summary>
		/// 
		/// </summary>
		/// <returns></returns>
		public int get() {
			if (bPaused > 0) {
				return dwPauseTime - dwOffsetTime;
			}
			else {
				return getTime() - dwOffsetTime;
			}
		}

		/// <summary>
		/// 
		/// </summary>
		public void reset() {
			dwOffsetTime = getTime();
			bPaused = 0;
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="t"></param>
		public void set(int t) {
			if (bPaused > 0) {
				dwOffsetTime = dwPauseTime - t;
			}
			else {
				dwOffsetTime = getTime() - t;
			}

		}

		/// <summary>
		/// 
		/// </summary>
		public void pause() {
			if (bPaused++ == 0) {
				dwPauseTime = getTime();
			}
		}

		/// <summary>
		/// 
		/// </summary>
		public void restart() {
			if (--bPaused == 0) {
				dwOffsetTime += getTime() - dwPauseTime;
			}
		}

		/// <summary>
		/// 
		/// </summary>
		protected int dwOffsetTime;
		/// <summary>
		/// 
		/// </summary>
		protected int dwPauseTime;
		/// <summary>
		/// 
		/// </summary>
		protected int bPaused;

		/// <summary>
		/// 
		/// </summary>
		/// <returns></returns>
		private int getTime() { return getTimer_().getTime(); }

		/// <summary>
		/// 
		/// </summary>
		/// <returns></returns>
		private Timer_ getTimer_() { return timer_; }
		private static Timer_ timer_ = new Timer_();
	}
}
