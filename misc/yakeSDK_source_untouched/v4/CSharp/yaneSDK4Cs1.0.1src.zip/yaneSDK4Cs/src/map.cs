using System;
using System.Collections;

namespace y4cs.ytl
{
	/// <summary>
	/// 
	/// </summary>
	public class map
	{
		/// <summary>
		/// 
		/// </summary>
		public map() {
		}
	}
}
