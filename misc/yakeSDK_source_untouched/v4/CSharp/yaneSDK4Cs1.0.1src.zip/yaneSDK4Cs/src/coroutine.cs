using System;
using System.Threading;
using System.Collections;

namespace y4cs.aux {
	/// <summary>
	/// �R���[�`������������B
	/// </summary>
	/// <remarks>
	/// Thread�Ɠ����C�x���g���g���ăR���[�`�����G�~�����[�g���Ă��܂��B
	/// </remarks>
	public class Coroutine : IEnumerable, IEnumerator, IDisposable {
		/// <summary>
		/// �R���[�`������Ăяo�����delegate�B
		/// </summary>
		protected CoroutineStart start_proc;
		private Thread thread;
		private AutoResetEvent event1;
		private AutoResetEvent event2;
		private object result;
		private bool disposed;
		/// <summary>
		/// �R���[�`�����I���������ǂ����B
		/// </summary>
		protected volatile bool isDone_;

		/// <summary>
		/// �R���X�g���N�^�B
		/// </summary>
		public Coroutine() {}

		/// <summary>
		/// �R���X�g���N�^�B
		/// </summary>
		/// <param name="start"></param>
		public Coroutine(CoroutineStart start) {
			start_proc = start;
		}

		/// <summary>
		/// 
		/// </summary>
#if false
		~Coroutine() {
			Dispose(false);
		}
#endif
		/// <summary>
		/// 
		/// </summary>
		/// <param name="o"></param>
		public void Yield(object o) {
			result = o;
			Suspend();
		}

		/// <summary>
		/// 
		/// </summary>
		public void Start() {
			Reset();
		}

		private void Main() {
			event2.WaitOne();
			Run();
			isDone_ = true;
			event1.Set();
		}

		/// <summary>
		/// 
		/// </summary>
		protected void Resume() {
			event2.Set();
			event1.WaitOne();
		}

		/// <summary>
		/// 
		/// </summary>
		protected void Suspend() {
			event1.Set();
			event2.WaitOne();
		}

		/// <summary>
		/// 
		/// </summary>
		protected virtual void Run() {
			if (start_proc != null)
				start_proc(this);
		}

		/// <summary>
		/// 
		/// </summary>
		/// <returns></returns>
		public bool IsDone() {
			return isDone_;
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="disposing"></param>
		protected void Dispose(bool disposing) {
			if (!disposed) {
				if (disposing) {
					if (thread != null) {
						if (thread.IsAlive)
							thread.Abort();
						thread = null;
					}
				}
				if (event1 != null) {
					event1.Close();
					event1 = null;
				}
				if (event2 != null) {
					event2.Close();
					event2 = null;
				}
				disposed = true;
			}
		}

		#region IEnumerable �����o

		public IEnumerator GetEnumerator() {
			return this;
		}

		#endregion

		#region IEnumerator �����o

		public void Reset() {
			Dispose(true);
			event1 = new AutoResetEvent(false);
			event2 = new AutoResetEvent(false);
			thread = new Thread(new ThreadStart(Main));
			thread.IsBackground = true;
			thread.Start();
			isDone_ = false;
		}

		public object Current {
			get {
				return result;
			}
		}

		public bool MoveNext() {
			if (IsDone())
				return false;
			Resume();
			return !isDone_;
		}

		#endregion

		#region IDisposable �����o

		public void Dispose() {
			// Dispose(true);
			GC.SuppressFinalize(this);
		}

		#endregion
	}

	public delegate void CoroutineStart(Coroutine cor);
}
