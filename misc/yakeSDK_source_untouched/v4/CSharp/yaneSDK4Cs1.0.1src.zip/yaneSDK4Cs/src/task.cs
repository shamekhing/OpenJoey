using System;
using System.Collections;

// �^�X�N�V�X�e���́A�܂����Ȃ�Ă��Ȃ��̂ŕύX�����\����

namespace y4cs.task
{
	public delegate void TaskProc(TCB cb, object info);

	class InternalTask {
		public static void NullProc(TCB cb, object info) {}
	}

	// TaskControlBlock
	public class TCB {
		public string name;		// �^�X�N��(�f�o�b�O�p)
		public TaskProc proc;	// ����
		public int priority;	// �D��x
		public TCB prev;		// �O�^�X�N
		public TCB next;		// ���^�X�N
		public TCB parent;		// �e�^�X�N
		public object work;		// ��Ɨ̈�
		public bool dead;		// ���S�t���O

		public TCB() {}

		public void init() {
			init("", Int32.MaxValue - 1, null, null, null);
		}

		public void init(string name, int priority, TaskProc proc, TCB prev, TCB next) {
			this.name = name;
			this.priority = priority;
			this.proc = proc;
			this.prev = prev;
			this.next = next;
			if (prev != null)
				prev.next = this;
			if (next != null)
				next.prev = this;
			dead = false;
		}

		public override string ToString() {
			return String.Format("[TCB:{0}]", name);
		}
	}

	public class TaskList {
		TCB[] tasks;
		int read;
		int write;

		TCB hd;
		TCB tl;

		public TaskList(int size) {
			if (size < 2) 
				throw new ArgumentException("size must greater than two.", "size");
			tasks = new TCB[size];
			for (int i = 0; i < tasks.Length; ++i)
				tasks[i] = new TCB();
			read = write = 0;
			hd = tasks[0];
			tl = tasks[1];
			hd.init("HEAD", 0, new TaskProc(InternalTask.NullProc), null, tl);
			tl.init("TAIL", Int32.MaxValue, new TaskProc(InternalTask.NullProc), hd, null); 
			// �g�p���Ȃ̂�tasks��null�ɂ���
			tasks[0] = tasks[1] = null;
			read = 2;
			write = 0;
		}

		public TCB head {
			get { return hd; }
		}

		public TCB tail {
			get { return tl; }
		}

		public TCB make(int priority, TaskProc proc) {
			return make("", priority, proc);
		}

		public TCB make(string name, int priority, TaskProc proc) {
			if (read == write) {
				// �󂫂��Ȃ�
				return null;
			}

			TCB cb = tasks[read]; tasks[read++] = null;
			if (read == tasks.Length)
				read = 0;

			TCB prev = null;
			TCB i = head;
			while (i != null) {
				if (i.priority < priority) {
					if (prev == null || prev.priority < i.priority)
						prev = i;
				}
				i = i.next;
			}

			cb.init(name, priority, proc, prev, prev.next);

			return cb;
		}

		public void free(TCB cb) {
			if (cb == null)
				throw new ArgumentNullException("cb");

			cb.prev.next = cb.next;
			cb.next.prev = cb.prev;

			cb.init();
			tasks[write++] = cb;
			if (write == tasks.Length)
				write = 0;
		}
	}

	public class TaskController {
		TaskList list;
		public TaskController(TaskList list) {
			this.list = list;
		}

		public void call(object info) {
			TCB cb = list.head;
			while (cb != null) {
				if (!cb.dead)
					cb.proc(cb, info);
				cb = cb.next;
			}
		}

		public TCB add(string name, int priority, TaskProc proc, Type workType, params object[] args) {
			object work = Activator.CreateInstance(workType, args);
			return add(name, priority, proc, work);
		}

		public TCB add(string name, int priority, TaskProc proc) {
			return add(name, priority, proc, (object)null);
		}

		public TCB add(string name, int priority, TaskProc proc, object work) {
			TCB cb = list.make(name, priority, proc);
			if (cb != null) {
				cb.proc = proc;
				cb.work = work;
			}
			return cb;
		}

		public void kill(TCB cb) {
			// null�͎E���Ȃ�
			if (cb == null)
				throw new ArgumentNullException("cb");

			// head, tail�͎E���Ȃ�
			if (cb == list.head || cb == list.tail)
				throw new InvalidOperationException();

			cb.dead = true;
		}

		/// <summary>
		/// priority��[begin, end)�̃^�X�N���E��
		/// </summary>
		/// <param name="begin"></param>
		/// <param name="end"></param>
		public void kill(int begin, int end) {
			if (begin >= end || begin <= 0 || end >= Int32.MaxValue)
				return;

			TCB cb = list.head;
			while (cb != null) {
				if (cb.priority >= begin && cb.priority < end)
					kill(cb);
				cb = cb.next;
			}
		}

		/// <summary>
		/// dead��Ԃ̃^�X�N���ĎE
		/// </summary>
		public void clean() {
			TCB cb = list.head;
			while (cb != null) {
				TCB t = cb;
				cb = cb.next;
				if (t.dead) 
					list.free(t);					
			}
		}
	}
}
