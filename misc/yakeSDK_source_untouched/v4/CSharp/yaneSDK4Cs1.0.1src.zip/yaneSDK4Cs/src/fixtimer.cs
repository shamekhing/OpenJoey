using System;

namespace y4cs.timer
{
	/// <summary>
	/// FixTimer
	/// </summary>
	public class FixTimer
	{
		/// <summary>
		/// 
		/// </summary>
		public void reset() { timer.reset(); dwTimeGetTime = 0; }
		/// <summary>
		/// 
		/// </summary>
		/// <returns></returns>
		public int get() { return dwTimeGetTime; }
		/// <summary>
		/// 
		/// </summary>
		/// <param name="t"></param>
		public void set(int t) { timer.set(t); }
		/// <summary>
		/// 
		/// </summary>
		public void pause() { timer.pause(); }
		/// <summary>
		/// 
		/// </summary>
		public void restart() { timer.restart(); }

		/// <summary>
		/// 
		/// </summary>
		public void update() {
			dwTimeGetTime = timer.get();
		}

		/// <summary>
		/// 
		/// </summary>
		public FixTimer() { timer = new Timer(); dwTimeGetTime = 0;}

		/// <summary>
		/// 
		/// </summary>
		protected Timer timer;
		/// <summary>
		/// 
		/// </summary>
		protected int dwTimeGetTime;
	}
}
